"""Final pre-writing experiments (one queue, 2 workers, priority order):
 T4  stage-1 control: stage 2 always 300 epochs with a fresh optimiser + cosine restart;
     stage1 in {25, 50, 100}; stage1 = 0 is the simultaneous hybrid (300 epochs). MLP with 200 epochs.
 T2  unstructured second-order Neural ODE (RK4), both truths.
 T1  N_c criterion with exact-phase Boris: 3 storms x 4 K around the bound; K sweep on ring-current truth."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
P = "exact_phase=True data=data/dataset_prc.npz"
jobs = []
for s in range(10):                                                     # ---- T4
    for st in (25, 50, 100):
        jobs.append((f"prc_shyb_l2_st{st}r_K64", s, f"K=64 {P} model=hybrid l_max=2 lam_reg=0.1 stage1={st} epochs={st + 300} restart_stage2=True", "prc"))
    if s >= 3:
        jobs.append(("prc_hyb_l2_K64", s, f"K=64 epochs=300 {P} model=hybrid l_max=2 lam_reg=0.1", "prc"))
    jobs.append(("prc_mlp_ep200_K64", s, f"K=64 epochs=200 {P}", "prc"))
for s in range(5):                                                      # ---- T2
    jobs.append(("prc_node_K64", s, f"K=64 epochs=300 model=node {P}", "prc"))
    jobs.append(("xp_node_K48", s, "K=48 epochs=300 model=node", "storm"))
KS = {0.5: (24, 20, 16, 12), 1.0: (48, 40, 32, 24), 2.0: (96, 80, 64, 48)}   # N/N_c = 0.70, 0.84, 1.04, 1.39
for s in range(3):                                                      # ---- T1
    for storm, Ks in KS.items():
        d = "data/dataset.npz" if storm == 1.0 else f"data/dataset_storm{storm:g}.npz"
        for K in Ks:
            jobs.append((f"threshold_xp/xpthr_storm{storm:g}_K{K}", s, f"K={K} epochs=300 exact_phase=True data={d}", "storm"))
    for K in (24, 32, 48):
        jobs.append((f"prc_mlp_K{K}", s, f"K={K} epochs=300 {P}", "prc"))

def run(j):
    name, s, args, truth = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    with open(f"outputs/logs/{os.path.basename(name)}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=dict(os.environ, RB_TRUTH=truth))
    print("done", name, s, flush=True)

print(len(jobs), "jobs", flush=True)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("FINAL DONE", flush=True)
