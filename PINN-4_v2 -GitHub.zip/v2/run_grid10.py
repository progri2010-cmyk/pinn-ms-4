"""Tenth round: independent confirmation, seeds 10-21 (4 groups of 3) for the out-of-basis head-to-head (MLP vs staged hybrid l<=2, lam=0.1)."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
P = "K=64 epochs=300 exact_phase=True data=data/dataset_prc.npz"
cfgs = {"prc_mlp_K64": P, "prc_shyb_l2_lam01_K64": f"{P} model=hybrid l_max=2 lam_reg=0.1 stage1=100"}
jobs = [(n, s, a) for s in range(10, 22) for n, a in cfgs.items()]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=dict(os.environ, RB_TRUTH="prc"))
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID10 DONE")
