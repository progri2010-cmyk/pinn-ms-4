"""
physics/fields.py -- dimensionless magnetic field models (float64).

Units
-----
length : Earth radius R_E
speed  : particle speed |v| (so |v| = 1 initially)
time   : R_E / |v|
field  : equatorial dipole field at L0 = 4

Equation of motion:  dv/dt = (s/eps) v x B(r),   s = -1 (electron),
eps = r_L / R_E at the reference field. eps = 0.02 keeps r_L/R_E small
(adiabatic) while gyro : bounce : drift stay resolvable on a CPU.

True field = dipole (known physics) + storm perturbation (unknown to the model):
  dB_storm = -b_s z_hat + (b_a / L0) * (z, 0, x)
The first term is the symmetric ring-current depression, the second a
day-night asymmetry. Both are curl- and divergence-free (vacuum field).
"""
import os
import numpy as np
import torch

L0 = 4.0
EPS = 0.02
SIGN = -1.0          # electron
B_S = 0.15           # symmetric depression (15% of B_eq(L0), ~ -70 nT, moderate storm)
B_A = 0.06           # day-night asymmetry


def dipole_np(r):
    x, y, z = r[..., 0], r[..., 1], r[..., 2]
    r2 = x * x + y * y + z * z
    r5 = r2 ** 2.5
    k = L0 ** 3
    # m = -z_hat (Earth), B = (3 (m.r) r - m r^2) / r^5
    Bx = -3.0 * k * x * z / r5
    By = -3.0 * k * y * z / r5
    Bz = k * (r2 - 3.0 * z * z) / r5
    return np.stack([Bx, By, Bz], -1)


def storm_np(r, b_s=B_S, b_a=B_A):
    x, z = r[..., 0], r[..., 2]
    zero = np.zeros_like(x)
    return np.stack([b_a * z / L0, zero, -b_s + b_a * x / L0], -1)


def true_field_np(r, b_s=B_S, b_a=B_A):
    return dipole_np(r) + storm_np(r, b_s, b_a)


def dipole_torch(r):
    x, y, z = r[..., 0], r[..., 1], r[..., 2]
    r2 = x * x + y * y + z * z
    r5 = r2 ** 2.5
    k = L0 ** 3
    return torch.stack([-3 * k * x * z / r5, -3 * k * y * z / r5,
                        k * (r2 - 3 * z * z) / r5], -1)


def true_field_torch(r, b_s=B_S, b_a=B_A):
    x, z = r[..., 0], r[..., 2]
    st = torch.stack([b_a * z / L0, torch.zeros_like(x), -b_s + b_a * x / L0], -1)
    return dipole_torch(r) + st


# ---- choice of "true" field: RB_TRUTH=storm (default, in the l<=2 harmonic basis)
#      or RB_TRUTH=prc (distributed asymmetric ring current, out of any harmonic basis)
TRUTH = os.environ.get("RB_TRUTH", "storm")
if TRUTH == "prc":
    from physics.ring_current import ring_field

    def true_field_np(r, b_s=None, b_a=None):          # storm kwargs ignored
        return dipole_np(r) + ring_field(r, np)

    def true_field_torch(r, b_s=None, b_a=None):
        return dipole_torch(r) + ring_field(r, torch)
