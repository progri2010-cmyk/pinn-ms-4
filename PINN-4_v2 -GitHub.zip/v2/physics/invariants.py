"""
physics/invariants.py -- diagnostics measured with the TRUE field.

mu  : v_perp^2 / |B|, smoothed over one local gyro-period
J   : integral of v_par^2 dt over each full bounce (= closed p_par ds)
L   : dipole L of the guiding centre, r_gc / cos^2(lat_gc)
phi : drift azimuth of the guiding centre (unwrapped)
"""
import numpy as np
from physics.fields import true_field_np, EPS, SIGN


def smooth(x, w):
    if w <= 1:
        return x
    k = np.ones(w) / w
    pad = w // 2
    xp = np.pad(x, [(0, 0)] * (x.ndim - 1) + [(pad, w - 1 - pad)], mode="edge")
    return np.apply_along_axis(lambda a: np.convolve(a, k, mode="valid"), -1, xp)


def guiding_centre(r, v, field=true_field_np):
    B = field(r)
    B2 = np.sum(B * B, -1, keepdims=True)
    return r + SIGN * EPS * np.cross(v, B) / B2


def mu(r, v, dt_obs, field=true_field_np):
    B = field(r)
    Bm = np.linalg.norm(B, axis=-1)
    vpar = np.sum(v * B, -1) / Bm
    vperp2 = np.sum(v * v, -1) - vpar ** 2
    w = max(1, int(round(2 * np.pi * EPS / dt_obs)))
    return smooth(vperp2 / Bm, w)


def v_parallel(r, v, field=true_field_np):
    B = field(r)
    return np.sum(v * B, -1) / np.linalg.norm(B, axis=-1)


def bounce_J(r, v, dt_obs, field=true_field_np, max_bounces=None):
    """Return J for each complete bounce (between every 2nd mirror point)."""
    w = max(1, int(round(2 * np.pi * EPS / dt_obs)))
    vp = smooth(v_parallel(r, v, field), w)
    idx = np.where(np.diff(np.sign(vp)) != 0)[0]
    Js = []
    for a, b in zip(idx[:-2:2], idx[2::2]):
        Js.append(np.sum(vp[a:b] ** 2) * dt_obs)
    Js = np.array(Js)
    return Js if max_bounces is None else Js[:max_bounces]


def lshell_gc(r, v, field=true_field_np):
    g = guiding_centre(r, v, field)
    rr = np.linalg.norm(g, axis=-1)
    coslat2 = (g[..., 0] ** 2 + g[..., 1] ** 2) / rr ** 2
    return rr / coslat2


def drift_phase(r, v, field=true_field_np):
    g = guiding_centre(r, v, field)
    return np.unwrap(np.arctan2(g[..., 1], g[..., 0]), axis=-1)
