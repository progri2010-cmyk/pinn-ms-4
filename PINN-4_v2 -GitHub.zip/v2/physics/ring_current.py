"""
physics/ring_current.py -- out-of-basis "true" storm field: a distributed,
asymmetric westward ring current that flows THROUGH the electron region.

Seven circular current loops in the equatorial plane, radii 3.0-6.0 R_E,
Gaussian current profile peaked at 4.5 R_E, centres displaced toward dusk (+y)
and night (-x) in proportion to radius (partial-ring-current-like asymmetry).
Each loop is discretised into straight segments and its field is the curl of
a regularised vector potential
    A = sum I dl / sqrt(|r - r'|^2 + a_c^2)   =>   B = sum I dl x R / (|R|^2 + a_c^2)^{3/2},
so div B = 0 exactly while curl B != 0 inside the current layer (not a vacuum
field): no finite harmonic expansion represents it.
Works with numpy or torch arrays (xp argument).
"""
import numpy as np

RADII = np.linspace(3.0, 6.0, 7)
WEIGHTS = np.exp(-(RADII - 4.5) ** 2 / (2 * 0.7 ** 2))
SHIFT = np.stack([-0.05 * RADII, 0.08 * RADII, 0 * RADII], -1)
CORE = 0.5
NSEG = 96
SCALE = 1.0           # set below so that the depression at L0 = 4 is ~15% of B_eq


def _segments():
    th = np.linspace(0, 2 * np.pi, NSEG + 1)
    mids, dls, cur = [], [], []
    for a, w, c in zip(RADII, WEIGHTS, SHIFT):
        p = np.stack([a * np.cos(th), a * np.sin(th), 0 * th], -1) + c
        p = p[::-1]                                   # clockwise seen from north = westward
        mids.append(0.5 * (p[1:] + p[:-1])); dls.append(p[1:] - p[:-1]); cur.append(np.full(NSEG, w))
    return np.concatenate(mids), np.concatenate(dls), np.concatenate(cur)


MID, DL, CUR = _segments()


def ring_field(r, xp=np):
    mid, dl, cur = MID, DL, CUR
    if xp is not np:
        mid, dl, cur = (xp.as_tensor(a, dtype=r.dtype) for a in (mid, dl, cur))
    R = r[..., None, :] - mid                          # (..., S, 3)
    den = ((R * R).sum(-1) + CORE ** 2) ** 1.5         # (..., S)
    cr = xp.stack([dl[:, 1] * R[..., 2] - dl[:, 2] * R[..., 1],
                   dl[:, 2] * R[..., 0] - dl[:, 0] * R[..., 2],
                   dl[:, 0] * R[..., 1] - dl[:, 1] * R[..., 0]], -1)
    return SCALE * ((cur / den)[..., None] * cr).sum(-2)


# normalise: mean B_z perturbation on the L0 equatorial ring = -0.15
_ring = np.stack([4.0 * np.cos(np.linspace(0, 2 * np.pi, 72)),
                  4.0 * np.sin(np.linspace(0, 2 * np.pi, 72)), np.zeros(72)], -1)
SCALE = -0.15 / ring_field(_ring)[:, 2].mean()
