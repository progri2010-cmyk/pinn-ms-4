"""
physics/boris.py -- batched Boris pusher (numpy float64 for ground truth,
torch for the differentiable model). Field is evaluated at the half-step
position (leapfrog), which keeps the scheme second order and volume
preserving; in a static B it conserves |v| to round-off.
"""
import numpy as np
import torch
from physics.fields import EPS, SIGN


def boris_np(r, v, dt, field, eps=EPS, s=SIGN):
    rh = r + 0.5 * dt * v
    t = (s / eps) * field(rh) * (0.5 * dt)
    t2 = np.sum(t * t, -1, keepdims=True)
    vp = v + np.cross(v, t)
    v_new = v + np.cross(vp, 2.0 * t / (1.0 + t2))
    r_new = rh + 0.5 * dt * v_new
    return r_new, v_new


def boris_torch(r, v, dt, field, eps=EPS, s=SIGN, exact_phase=False):
    """exact_phase=True: rotation vector t = tan(theta/2) t_hat instead of theta/2,
    which makes the gyro-phase per step exact in a locally uniform field
    (standard Boris lags by ~ (Omega dt)^2 / 12 per radian)."""
    rh = r + 0.5 * dt * v
    t = (s / eps) * field(rh) * (0.5 * dt)
    if exact_phase:
        tn = t.norm(dim=-1, keepdim=True)
        t = t * torch.tan(tn) / tn
    t2 = (t * t).sum(-1, keepdim=True)
    vp = v + torch.cross(v, t, dim=-1)
    v_new = v + torch.cross(vp, 2.0 * t / (1.0 + t2), dim=-1)
    r_new = rh + 0.5 * dt * v_new
    return r_new, v_new


def integrate_np(r0, v0, dt, n_steps, field, save_every=1):
    r, v = r0.copy(), v0.copy()
    R, V = [r.copy()], [v.copy()]
    for k in range(1, n_steps + 1):
        r, v = boris_np(r, v, dt, field)
        if k % save_every == 0:
            R.append(r.copy()); V.append(v.copy())
    return np.stack(R, -2), np.stack(V, -2)   # (..., T, 3)
