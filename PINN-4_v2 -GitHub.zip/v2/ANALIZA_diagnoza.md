# PINN-4: analiza e gjendjes dhe rindërtimi (v2)

## 1. Diagnoza e kodit ekzistues (PUNIMI-4, v1)

Rezultati në `table1.csv` (RMSE pozicioni 1.0e-6, drift energjie 0, drift L 0) nuk përfaqëson fizikë. U verifikua drejtpërdrejt mbi `radiation_belt_data.npz` dhe `rollout_results.npz`:

| Problemi | Prova | Pasoja |
|---|---|---|
| Pozicionet në float32 me hap 1.4 cm, në r = 2.55e7 m | Hapësira e float32 te 4 R_E është 2.0 m; koordinata x ka **1 vlerë unike** në 100 000 hapa | Pozicioni nuk lëviz kurrë. RMSE pozicioni ≈ 0 dhe drifti L = 0 janë artefakte |
| Dataset-i mbulon 1e-4 s | Periudha e gjirimit te L=4 është 74 µs, pra **1.34 gjirime**, pa kërcim dhe pa drift | Nuk ka asnjë nga tri shkallët kohore përveç një pjese gjirimi |
| Normalizim i paqëndrueshëm | r/R_E dhe v/1e7, por dt = 1e-9 dhe q/m = −1 lihen "fizikë" | Rrotullimi i shpejtësisë për hap është ~1e-9, modeli është praktikisht identitet. Shpejtësia e parashikuar mbetet (1,0,1) |
| Segmentet MIC krahasohen me indekset gabim | 16 segmente nisin çdo 6666 hapa, por krahasohen me `positions[:16000]` | Humbja e të dhënave krahason pika që s'kanë lidhje |
| Lorentz në humbje me peshë 1e-20 | `total_loss` | Termi fizik nuk ndikon fare |
| Autograd i dyfishtë për curl A në çdo hap | log-u i Modelit B: 345–413 s/epokë, 9.5 orë për 100 epoka | Trajnim jopraktik. L_traj = 2.14e-9 konstant, L_vel ≈ 0.5 nuk zbret |

Përfundimi: Faza 3 v1 nuk ka rezultate të përdorshme dhe asnjë numër prej saj s'duhet të hyjë në punim. Ideja e modelit (potencial vektor A_θ → B = curl A, Boris i diferencueshëm, MIC) ishte e drejtë; zbatimi jo.

## 2. Çfarë u ndryshua në v2

1. **Njësi pa dimension, float64.** Gjatësia në R_E, shpejtësia në |v|, koha në R_E/|v|, fusha në B_eq(L=4). Ekuacioni është dv/dt = (s/ε) v × B, me ε = r_L/R_E = 0.02 (adiabatik, por me tri shkallë të rezolvueshme në CPU).
2. **Ground truth:** Boris float64 me dt = 5e-4. Energjia ruhet në 4e-14, J në 1e-7, L në 4e-5. Gjirimi 0.126, kërcimi 13, drifti ~3300, pra raporti ~1 : 100 : 26 000.
3. **Fusha e vërtetë = dipol + stuhi** (e panjohur për modelin): −b_s ẑ (depresion simetrik i rrymës unazore, 15% e B_eq ≈ −70 nT) + asimetri ditë-natë b_a(z,0,x)/L0. Të dyja janë pa rrotullim dhe pa divergjencë.
4. **Modeli hibrid:** B_θ = B_dipol + curl A_θ. Jakobiani dA/dr përhapet analitikisht brenda MLP-së (përputhet me autograd në 1e-16). div B = 0 vlen identikisht (2e-18), pa autograd të dyfishtë. Shpejtësia: 0.4 s/epokë, në vend të 400 s.
5. **MIC i vërtetë:** gjendjet e nyjeve janë parametra të trajnueshëm, me humbje vazhdimësie. Pozicionet shkallëzohen me ε dhe shpejtësitë me 1, që gabimi i fazës të peshojë njësoj.
6. **Dataset:** 6 elektrone trajnimi (~1 kërcim secili, zhurmë 10% e r_L) në gjatësi të ndryshme gjeografike; 8 elektrone testi të paparë në horizont 10× (140 njësi).
7. **Metrikat** maten me fushën e vërtetë: RMSE i qendrës udhëheqëse (GC) për fazën e kërcimit dhe driftit, gabimi i μ, i J për çdo kërcim, i L të GC (proxy i Φ) dhe i fazës së driftit.

## 3. Rezultatet e Fazës 3–4 (v2)

Testi: 8 elektrone të paparë, horizont 10× (140 njësi ≈ 10 kërcime). Të gjithë modelet integrohen me Boris me të njëjtin hap. Vlerat janë mesatare ± std mbi seed-et: 5 për K=48, 3 për të tjerët, 2 për single shooting.

| Metoda | Humbja e të dhënave | GC RMSE 10× [R_E] | Gabimi μ | Gabimi J | Gabimi L_gc | Faza e driftit [rad] | Koha |
|---|---|---|---|---|---|---|---|
| Fusha e vërtetë (kufiri) | – | 3.0e-4 | 0.36% | 7.6e-7 | 6.7e-5 | 1.1e-5 | – |
| Vetëm dipol (pa mësim) | – | 1.03 | 5.0% | 50.6% | 0.024 | 0.085 | – |
| **MIC uniform K=48** | 0.034 | **0.462 ± 0.008** | **0.84%** | **2.28 ± 0.12%** | 0.0116 | 0.0143 | 110 s |
| Adaptiv κ^½ K=48 | 0.034 | 0.472 ± 0.014 | 0.87% | 2.45 ± 0.13% | 0.0120 | 0.0139 | 158 s |
| Adaptiv κ¹ K=48 | 0.034 | 0.493 ± 0.022 | 0.93% | 2.79 ± 0.14% | 0.0132 | 0.0139 | 247 s |
| Adaptiv gabim K=48 | 0.034 | 0.466 ± 0.007 | 0.84% | 2.34 ± 0.16% | 0.0117 | 0.0140 | 127 s |
| MIC uniform K=32 | 0.43 | 0.949 | 5.6% | 30.4% | 0.042 | 0.057 | 124 s |
| MIC uniform K=24 | 1.47 | 0.799 | 3.5% | 31.1% | 0.026 | 0.076 | 149 s |
| Single shooting | 3.65 | 0.867 | 1.8% | 11.0% | 0.018 | 0.044 | 3120 s |
| Fushë black-box K=48 | 3.09 | 37 (shpërthen) | 45% | 87% | 416 | 0.64 | 106 s |

Energjia ruhet në ~3e-14 nga të gjithë modelet me Boris, ndaj nuk dallon metodat. Ajo dallon vetëm kundër një Neural ODE të pastrukturuar, që nuk u testua ende.

**Çfarë tregojnë rezultatet**

1. **Prior-i fizik + Boris i diferencueshëm funksionon.** Ndaj dipolit pa mësim, gabimi i J bie 22×, i μ 6× dhe i fazës së driftit 6×. Pa prior (black-box), trajnimi dështon dhe elektronet ikin.
2. **Hipoteza "segmentim adaptiv sipas lakimit > uniform" nuk konfirmohet.** Te K=48 uniform fiton në 29 nga 30 krahasimet seed-për-seed (3 variante adaptive × 2 metrika × 5 seed). Për çdo variant Wilcoxon jep p = 0.0625–0.125, ndërsa minimumi i mundshëm me n=5 është 0.0625. Diferenca është 1–22%. Te K=32 adaptivi ul pak humbjen e trajnimit (0.40 kundrejt 0.43, në 3/3 seed), por jo gabimin në test. Arsyeja: κ ndryshon përgjatë orbitës vetëm 1.1–4.4 herë, sepse gjirimi, kërcimi dhe drifti ndodhin njëkohësisht, jo njëri pas tjetrit. Pritja e mëparshme "~1000× më shumë segmente gjatë gjirimit" nuk kishte bazë.
3. **Gjetja e re (e konfirmuar): kufiri i mbështjelljes së fazës.** Me gabim fillestar relativ të fushës δ, faza ciklotronike gabon 2πNδ pas N gjirimesh. Kur kjo kalon π, humbja bëhet jo-konvekse dhe MIC ngec. Parashikimi është N_c = 1/(2δ) gjirime për segment. U testua me tri forca stuhie (b_s = 0.075, 0.15, 0.30) × 4–6 vlera K. Kufiri N = N_c ndan konvergjencën nga dështimi në të tre regjimet; i vetmi përjashtim është një pikë 4% mbi kufi (fig5). Kjo jep rregull praktik: K ≥ T·Ω·δ/π segmente për trajektore.

## 4. Pasojat për punimin

Titulli dhe kontributi duhen rishikuar. "Curvature-adaptive" si kontribut kryesor nuk mbështetet nga të dhënat dhe referuesit do ta vënë re. Propozimi:

> *Phase-Wrapping-Aware Multiple Shooting for Learning Divergence-Free Magnetic Fields from Radiation-Belt Electron Trajectories*

Tre kontributet:
- (i) model hibrid B = B_dipol + curl A_θ me Jakobian analitik (div B = 0 ekzakt), i trajnuar përmes Boris të diferencueshëm;
- (ii) kriteri N_c = 1/(2δ) për gjatësinë e segmenteve MIC në sisteme me gjirim, i verifikuar eksperimentalisht;
- (iii) vlerësim mbi tre invariantët μ, J, Φ.

Segmentimi adaptiv sipas lakimit raportohet si ablacion me rezultat neutral/negativ. Kjo është e ndershme, dhe ICML/NeurIPS e pranojnë kur shpjegohet arsyeja fizike.

## 5. Raundi i dytë i analizës (39 trajnime shtesë)

### 5.1 Kufiri i mbështjelljes së fazës: tani me 52 trajnime

Për çdo forcë stuhie N është numri i gjirimeve të vërteta për segment dhe N_c = 1/(2δ), me δ = b_s/(1−b_s). Një trajnim quhet i konvergjuar kur humbja është < 0.06; vlerat janë bimodale (≤ 0.041 ose ≥ 0.43), me një përjashtim të vetëm.

| Stuhia b_s | N_c | K | N/N_c | seed | Humbja (mesatare) | Konvergjuan |
|---|---|---|---|---|---|---|
| 0.075 | 6.2 | 12 / 14 / **16** / 20 / 24 / 32 | 1.39 / 1.19 / **1.04** / 0.84 / 0.70 / 0.52 | 3/3/3/3/1/1 | 1.44 / 1.02 / **0.041** / 0.039 / 0.037 / 0.035 | 0/0/**3**/3/1/1 |
| 0.15 | 2.8 | 16 / 24 / 32 / 40 / 48 / 64 / 96 | 2.09 / 1.39 / 1.04 / 0.84 / 0.70 / 0.52 / 0.35 | 3/3/3/3/5/3/5 | 2.01 / 1.47 / 0.43 / 0.036 / 0.034 / 0.033 / 0.030 | 0/0/0/3/5/3/5 |
| 0.30 | 1.2 | 32 / 48 / 64 / **80** / 96 | 2.09 / 1.39 / 1.04 / **0.84** / 0.70 | 1/3/3/3/3 | 2.46 / 1.97 / 1.42 / **0.066** / 0.033 | 0/0/0/**2**/3 |

Rregulli "konvergjon ⇔ N < N_c" klasifikon saktë 48 nga 52 trajnime (92%). Të katër gabimet bien në zonën kalimtare 0.84 ≤ N/N_c ≤ 1.04. Jashtë intervalit ±17% rreth N_c klasifikimi është 100% i saktë, dhe ndryshimi i seed-it nuk e ndryshon rezultatin (std e humbjes < 0.03). Pragu real zhvendoset pak sipas forcës së stuhisë: mbi N_c për stuhinë e dobët, nën të për të fortën. Kjo pritet, sepse linearizimi 2πNδ < π e mbivlerëson gabimin jashtë ekuatorit (aty B është më e madhe dhe δ relativ më i vogël) dhe e nënvlerëson kur δ është i madh. Në punim kjo duhet thënë qartë: N_c është vlerësim i rendit të madhësisë me saktësi ~±20%, jo prag ekzakt.

### 5.2 Kurrikula e segmenteve dhe mbifitimi me segmente shumë të shkurtra

Kurrikula nis me K=96 dhe e përgjysmon K-në sa herë humbja bie nën 0.05 (min. 40 epoka ndërmjet), deri te K=24. Segmentet e bashkuara nisin nga gjendjet e parashikuara nga vetë modeli. Në të 5 seed-et bashkimet ndodhën te epokat 40 dhe 80.

| Metoda (5 seed) | Humbja e trajnimit | GC RMSE 10× | Gabimi J | Gabimi μ | Koha |
|---|---|---|---|---|---|
| Uniform K=96 | 0.0300 | 0.510 ± 0.014 | 2.95 ± 0.28% | 1.12% | 116 s |
| Uniform K=48 | 0.0344 | 0.462 ± 0.008 | 2.28 ± 0.12% | 0.84% | 110 s |
| **Kurrikula 96→48→24** | 0.0389 | **0.445 ± 0.021** | 2.34 ± 0.16% | 0.89% | 154 s |

Tri përfundime:
- **K=96 mbifiton.** Humbja e trajnimit (0.0300) bie te niveli teorik i zhurmës (0.0303), por gabimi në test është 10–34% më i keq se te K=48 (0/5 fitore në GC, J dhe μ; Mann–Whitney p = 0.008). Me segmente shumë të shkurtra, gjendjet e lira të nyjeve thithin gabimin, dhe fusha kufizohet më pak. Pra K-ja ka dy kufij: N < N_c, që faza të mos mbështillet, por jo shumë më i vogël, që çdo segment të mbajë mjaft gjirime për ta kufizuar fushën.
- **Kurrikula mund K=96 në 5/5 seed**: GC −13%, J −21%, μ −20% (Mann–Whitney p = 0.008 për GC dhe J, 0.03 për μ). Ndaj K=48 të zgjedhur me dorë del e barabartë (GC −3.5%, p = 0.15; J +2.9%, p = 0.69).
- **Vlera praktike:** kurrikula arrin rezultatin e K-së optimale pa e ditur paraprakisht δ dhe N_c. Në fund punon me K=24 (N = 3.9 > N_c = 2.8), që nga fillimi dështon (humbja 1.47). Kjo konfirmon kufirin edhe nga ana tjetër: δ i vogël lejon segmente më të gjata. Kosto: +40% kohë.

### 5.3 Më shumë të dhëna (12 trajektore në vend të 6): pa përmirësim

Testi dhe 6 trajektoret e para mbetën identike. Me K=48 dhe 3 seed: GC 10× 0.490 ± 0.017 (+6%, Mann–Whitney p = 0.07), J 2.61% (+15%, p = 0.39), μ 0.82% (−2%). Analiza për çdo elektron të testit tregon pse: me 6 trajektore gabimi i J ndryshon shumë nga elektroni në elektron (0.001% deri 5.4%), kurse me 12 bëhet më i njëtrajtshëm (1.2–4.0%), por mesatarja nuk bie. Kufizuesi aktual nuk është sasia e të dhënave. Shkaqet e mundshme janë kapaciteti/rregullimi i rrjetit (λ_reg, 300 epoka, 64 neurone) ose identifikueshmëria e komponentëve tërthorë të fushës, të cilët ndikojnë dobët në lëvizjen e gjirimit. Kjo nuk është provuar ende.

## 6. Struktura e propozuar e kontributeve (e tejkaluar: versioni përfundimtar është te 10.3 dhe 11.4)

1. Model hibrid B = B_dipol + curl A_θ me Jakobian analitik (div B = 0 ekzakt), i trajnuar përmes Boris të diferencueshëm. Rezultat: gabimi i J bie 22× ndaj dipolit, ndërsa modeli pa prior dështon.
2. Kriteri i mbështjelljes së fazës N_c = 1/(2δ) për MIC në sisteme me gjirim, i verifikuar në 52 trajnime me tri forca stuhie (92% saktësi; 100% jashtë ±17%).
3. Kurrikula e segmenteve që rrjedh nga kriteri: arrin rezultatin e K-së optimale pa akordim dhe shmang mbifitimin e segmenteve shumë të shkurtra.
4. Ablacion: segmentimi sipas lakimit (κ^½, κ¹) dhe sipas gabimit nuk e përmirëson uniformin (29/30 krahasime në favor të uniformit te K=48). Shpjegimi fizik: κ ndryshon vetëm 1.1–4.4× përgjatë orbitës.

## 7. Ku kufizohet gjeneralizimi: kapaciteti, rregullimi, zhurma, baza, integruesi

Të gjitha konfigurimet përdorin MIC uniform me K=48 dhe 300 epoka; 3 seed, përveç bazës (5). Krahasimet janë me Mann–Whitney (me n=3 kundrejt 5, p minimale e mundshme është 0.036; me 3 kundrejt 3 është 0.10, dhe me barazi vlerash 0.047). Figura përmbledhëse: `fig7_generalisation_limits`.

### 7.1 Kapaciteti, rregullimi, zhurma dhe të dhënat (MLP)

| Konfigurimi | Humbja e trajnimit | GC 10× [R_E] | Gabimi J | Gabimi μ | Ndryshimi GC / J |
|---|---|---|---|---|---|
| MLP 64, λ=1e-3 (baza) | 0.0344 | 0.462 | 2.28% | 0.84% | – |
| Të dhëna pa zhurmë | **0.0026** | 0.465 | 2.33% | 0.86% | +0.7% / +2.6% (p ≥ 0.79) |
| λ_reg = 0 … 1.0 (5 vlera) | 0.0344–0.0345 | 0.464–0.465 | 2.33–2.35% | 0.82–0.86% | ≤ +1% / ≤ +3% (p ≥ 0.39) |
| 12 trajektore | 0.0337 | 0.490 | 2.61% | 0.82% | +6% / +15% (p ≥ 0.07) |
| 600 epoka | 0.0331 | 0.479 | 2.67% | 0.88% | +4% / +18% (p ≥ 0.07) |
| 128 neurone | 0.0342 | 0.564 | 2.93% | 1.17% | +22% / +29% (p = 0.036) |
| 32 neurone | 0.0361 | 0.559 | 10.7% | 2.72% | +21% / +368% (p = 0.036) |

Asnjë nga këto nuk e përmirëson gjeneralizimin. Rezultati më i rëndësishëm është ai pa zhurmë: humbja e trajnimit bie 13×, kurse testi mbetet i pandryshuar. Rregullimi nuk ka ndikim sepse nuk frenon asgjë: madhësia e fushës së mësuar (|curl A|² = 0.0248) është praktikisht ajo e stuhisë së vërtetë (0.0249). 64 neurone është pika optimale; 32 nënfitojnë dhe 128 gjeneralizojnë më keq.

### 7.2 Çfarë e përcakton gabimin e J

Diagnostika e fushës mbi trajektoret e testit:
- gabimi paralel me B është 0.85% e |B| (6.5% e komponentit paralel të stuhisë), kurse ai tërthor është 11% e komponentit tërthor;
- gabimi i J për çdo elektron **nuk** lidhet me gabimin mesatar paralel (Spearman ρ = −0.20), as me largësinë nga trajektoret e trajnimit në gjatësi gjeografike (ρ = 0.05) apo në L (ρ = 0.09);
- lidhet fort me gabimin në **profilin e raportit të pasqyrimit** B(s)/B(s₀) përgjatë vijës së fushës: ρ = 0.91, p = 3e-16, n = 40 (5 seed × 8 elektrone).

Kjo ka kuptim fizik. Elektroni pasqyrohet aty ku B_model/B_model(s₀) = 1/sin²α, prandaj J varet nga forma relative e B përgjatë vijës, jo nga vlera absolute. MLP-ja e mëson mirë vlerën absolute, por e gabon formën deri në 10% për disa elektrone (mesatarisht 4.4%). Kjo ndodh edhe kur elektroni është afër të dhënave të trajnimit.

### 7.3 Baza me strukturë fizike: fushë e jashtme vakumi

B = B_dipol + ∇Φ, ku Φ = Σ c_k P_k(r/4), me P_k polinome harmonike të shkallës ≤ l (3, 8 ose 15 koeficientë). div B = curl B = 0 vlejnë me ndërtim. Kjo është forma standarde e ekspansioneve të fushës së jashtme në gjeomagnetizëm.

**Kujdes, kufizim i rëndësishëm:** fusha e stuhisë në simulim (depresion uniform + ∇(xz)) bie saktësisht në hapësirën l ≤ 2 (gabimi i përafrimit 4e-16), ndërsa l = 1 e mbulon vetëm me gabim 31%. Rezultati për l ≤ 2 tregon pra çfarë ndodh kur baza është e saktë. Ai **nuk** provon që metoda funksionon në kushte reale, ku rryma unazore është brenda zonës dhe fusha nuk është vakum i shkallës së ulët.

### 7.4 Gabimi i fazës së Boris kontaminon fushën e mësuar

Me Ωdt ≈ 0.2, Boris standard rrotullon 0.33% më ngadalë se fizika: (Ωdt)²/12, e verifikuar numerikisht si 1.04 rad pas 50 gjirimesh. Gjatë trajnimit modeli përpiqet të përputhet me fazën e gjirimit në të dhëna, prandaj e fryn |B| me rreth aq. Gabimi paralel i mbetur te l ≤ 2 ishte 0.45%. Varianti i Boris me fazë ekzakte (t = tan(θ/2)·t̂ në vend të θ/2) e heq këtë devijim (gabimi i fazës 4e-14 pas 50 gjirimesh), pa kosto shtesë.

| Modeli (3 seed) | Humbja e trajnimit | GC 10× | Gabimi J | Gabimi L_gc | Faza e driftit [rad] | Gabimi i profilit të pasqyrimit | Koha |
|---|---|---|---|---|---|---|---|
| MLP 64 (baza, 5 seed) | 0.0344 | 0.462 | 2.28% | 0.0116 | 0.0143 | 4.4% | 110 s |
| MLP 64 + fazë ekzakte | 0.0337 | 0.558 | 2.93% | 0.0148 | 0.0117 | 5.8% | 136 s |
| Harmonike l ≤ 1 | 0.120 | 0.931 | 11.2% | 0.0239 | 0.0282 | 13.8% | 29 s |
| Harmonike l ≤ 2 | 0.0371 | 0.229 | 0.62% | 0.0064 | 0.0037 | 1.2% | 35 s |
| Harmonike l ≤ 3 | 0.0348 | 0.585 | 3.54% | 0.0182 | 0.0028 | 6.2% | 49 s |
| **Harmonike l ≤ 2 + fazë ekzakte** | **0.0327** | **0.045** | **0.19%** | **0.0013** | **0.00045** | **0.32%** | 36 s |
| Harmonike l ≤ 3 + fazë ekzakte | 0.0329 | 0.305 | 1.67% | 0.0109 | 0.0023 | 2.7% | 56 s |
| Fusha e vërtetë (kufiri) | – | 3.0e-4 | 7.6e-7 | 6.7e-5 | 1.1e-5 | 0 | – |

Përfundimet e seksionit 7:
1. **Kufizimi i gjeneralizimit vjen nga dy burime të mbivendosura:** (a) inductive bias-i i MLP-së gjenerike, që nuk ekstrapolon saktë formën e B përgjatë vijave të fushës, dhe (b) devijimi i fazës së Boris, që e shtyn modelin ta frynë |B|. Zhurma, sasia e të dhënave, rregullimi dhe kapaciteti nuk janë kufizuesit.
2. Te MLP-ja dominon (a), dhe korrigjimi i fazës nuk ndihmon (GC +21%, p = 0.036; vetëm faza e driftit përmirësohet 18%). Te baza harmonike dominon (b): korrigjimi i fazës e ul GC 5×, J 3.2× dhe fazën e driftit 8× (3/3 seed).
3. Me të dy korrigjimet, gabimi bie ndaj MLP-së bazë 10× në GC, 12× në J, 9× në L dhe 32× në fazën e driftit. Modeli trajnohet edhe 3× më shpejt.
4. Liria e tepërt dëmton: l ≤ 3 del më keq se l ≤ 2, sepse koeficientët shtesë thithin zhurmën dhe devijimet. Prandaj zgjedhja e shkallës duhet bërë me një kriter të pavarur (validim në trajektore të veçanta ose kriter informacioni), jo duke e ditur përgjigjen.
5. **Rekomandim për punimin:** Boris me fazë ekzakte duhet të jetë standard brenda trajnimit; kjo është gjetje metodologjike më vete. Për fushën, modeli duhet të jetë bazë fizike + korrigjim i vogël MLP, i testuar me një fushë të vërtetë që **nuk** është në bazë.

## 8. Testi kritik jashtë bazës

### 8.1 Fusha e vërtetë e re

Fusha e re është dipol + rrymë unazore e shpërndarë dhe asimetrike, që kalon nëpër zonën e elektroneve: 7 unaza me rreze 3–6 R_E, profil gaussian me maksimum te 4.5 R_E dhe qendra të zhvendosura drejt muzgut dhe natës. Fusha llogaritet si curl i një potenciali vektor të rregulluar (bërthamë 0.5 R_E), prandaj div B = 0 ekzakt, ndërsa curl B ≠ 0 brenda shtresës së rrymës: fusha nuk është vakum. Depresioni te L=4 është 9–20% sipas gjatësisë gjeografike. Edhe me koeficientë optimalë, baza harmonike l ≤ 3 lë pa shpjeguar 45% të perturbimit (l ≤ 2: 67%). Elektronet mbeten adiabatike: J ruhet më mirë se 1e-4, kurse μ lëkundet 1.5–5% pa drift. Në të gjitha modelet u përdor K=64 (N ≈ 1.4 < N_c ≈ 2) dhe Boris me fazë ekzakte.

Për zgjedhjen e modelit u shtuan 4 elektrone validimi me zhurmë, që nuk përdoren kurrë në trajnim. **Humbja e validimit** është humbja e të dhënave e multiple shooting në këto elektrone, me nyje të fiksuara te vrojtimet me zhurmë. Ajo nuk kërkon njohjen e fushës së vërtetë. Edhe dataset-i i stuhisë mori këto elektrone; trajnimi dhe testi mbetën identikë.

### 8.2 Rezultatet (3 seed, test 10×)

Kandidatët janë: MLP; bazë harmonike l = 1, 2, 3; hibrid harmonike + MLP me trajnim të njëkohshëm (λ=0.1); dhe hibrid me dy faza, ku në 100 epokat e para trajnohet vetëm baza dhe pastaj shtohet MLP-ja me λ = 1 ose 10. Orakulli është baza me koeficientë të përshtatur me katrorët më të vegjël drejtpërdrejt mbi fushën e vërtetë.

| Modeli | Fusha e stuhisë (brenda bazës): validim / GC 10× / J | Rryma unazore (jashtë bazës): validim / GC 10× / J |
|---|---|---|
| Vetëm dipol | – / 1.03 / 50.6% | – / 0.94 / 54.2% |
| Orakull harmonik l ≤ 3 | – / 0.0012 / 0.006% | – / 0.62 / 27.0% |
| MLP | 0.075 / 0.558 / 2.93% | **0.092 / 0.504 / 7.5%** |
| Harmonike l ≤ 2 | 0.064 / 0.045 / 0.19% | 0.435 / 0.916 / 46.8% |
| Harmonike l ≤ 3 | 0.065 / 0.305 / 1.67% | 0.208 / 0.572 / 24.2% |
| Hibrid i njëkohshëm (l ≤ 2) | 0.106 / 0.421 / 2.97% | 0.118 / 0.579 / 20.4% (4.3–42%) |
| Hibrid i njëkohshëm (l ≤ 3) | – | 0.155 / 0.689 / 22.0% |
| **Hibrid me dy faza, λ=10** (l ≤ 2 te stuhia; l ≤ 3 te rryma) | **0.064 / 0.028 / 0.19%** | 0.183 / 0.703 / 27.4% |
| Hibrid me dy faza, λ=1 (po ato shkallë) | 0.064 / 0.028 / 0.21% | 0.215 / 0.773 / 23.2% |
| Fusha e vërtetë | – / 3e-4 / 1e-6 | – / 3e-4 / 1e-6 |

Shkalla l ≤ 3 për hibridin te rryma unazore u zgjodh me validim midis bazave harmonike (0.208 kundrejt 0.403 për l ≤ 1 dhe 0.435 për l ≤ 2).

### 8.3 Çfarë tregon testi

1. **Përmirësimi 10× i seksionit 7 nuk përgjithësohet.** Jashtë bazës, baza harmonike dështon (gabimi i J 24–47%). Kufiri vjen nga baza: me l ≤ 3 modeli i trajnuar (24%) arrin sa orakulli (27%). Hibridi me dy faza, që brenda bazës del më i miri, jashtë saj dështon (23–27%): faza e parë ngurtëson strukturë të gabuar, dhe rregullimi i fortë nuk e lë MLP-në ta korrigjojë.
2. **MLP-ja është zgjidhja e qëndrueshme** jashtë bazës. Ndaj dipolit e ul gabimin e J 7× (54% → 7.5%) dhe gabimin e profilit të pasqyrimit 6× (45% → 7.6%). Mbetet megjithatë larg fushës së vërtetë.
3. **Hibridi i njëkohshëm është i paqëndrueshëm sipas seed-it.** Ai jep rezultatin individual më të mirë jashtë bazës (J 4.3%), por edhe një nga më të këqijtë (42%).
4. **Gjetja kryesore, zgjedhja me validim funksionon pa njohur fushën e vërtetë.** Humbja e validimit korrelon me gabimin e J në test me ρ = 0.90 (stuhia, n = 21) dhe ρ = 0.81 (rryma, n = 24), dhe me gabimin GC me ρ = 0.95 dhe 0.83. Renditja e metodave sipas mesatares së validimit zgjedh hibridin me dy faza brenda bazës (J 0.19%, GC 0.028) dhe MLP-në jashtë bazës (J 7.5%, GC 0.50), pra familjen e duhur në të dyja rastet. Zgjedhja e trajnimit individual me validimin më të ulët jep 0.20% dhe 4.3%. Figura: `fig8_validation_selection`.

### 8.4 Rekomandimi i rishikuar për punimin (i përditësuar te 9.3)

Paraqitja e ndershme nuk është "modeli X fiton", por një procedurë:
- (i) Boris me fazë ekzakte brenda trajnimit;
- (ii) K i zgjedhur nga kriteri N_c, ose kurrikula e segmenteve;
- (iii) një grup i vogël kandidatësh me strukturë të ndryshme (MLP, bazë fizike, hibrid me dy faza);
- (iv) zgjedhja me humbjen e validimit në elektrone të veçanta.

Në të dyja fushat procedura e gjen modelin e duhur, dhe gabimi i J bie 7× deri 260× ndaj dipolit pa mësim. Rezultati jashtë bazës (J 7.5%) duhet raportuar si kufiri real aktual.

## 9. Një procedurë e vetme për të dyja fushat: hibridi me dy faza me l dhe λ të zgjedhur me validim

Hibridi me dy faza (100 epokat e para vetëm baza, pastaj baza + MLP së bashku) u trajnua tani me rrjetin e plotë λ ∈ {0.01, 0.1, 1, 10} për rregullimin e pjesës MLP, në të dyja fushat, me shkallë l ≤ 2 dhe l ≤ 3 për fushën jashtë bazës. Si zakonisht: 3 seed, Boris me fazë ekzakte, K=48 për stuhinë dhe K=64 për rrymën unazore. Konfigurimi (l, λ) zgjidhet me mesataren e humbjes së validimit, pa njohur fushën e vërtetë.

### 9.1 Rezultatet

| Konfigurimi | Validimi | GC 10× | Gabimi J | Gabimi μ | Faza e driftit | Gabimi i profilit të pasqyrimit |
|---|---|---|---|---|---|---|
| **Stuhia (brenda bazës)** | | | | | | |
| MLP | 0.0751 | 0.558 | 2.93% | 0.96% | 0.0117 | 5.8% |
| Hibrid me dy faza l≤2, λ = 0.01 / 0.1 / 1 / 10 | 0.0640 (të katra) | 0.029 / 0.029 / 0.028 / 0.028 | 0.21% / 0.21% / 0.21% / 0.19% | 0.31% | 0.0004–0.0005 | 0.28–0.29% |
| **Rryma unazore (jashtë bazës)** | | | | | | |
| MLP | 0.0920 | 0.504 ± 0.016 | 7.5 ± 2.3% | 1.32% | 0.042 | 7.6% |
| Hibrid i njëkohshëm l≤2, λ=0.1 | 0.118 | 0.579 ± 0.155 | 20.4 ± 19.5% | 3.48% | 0.042 | 14.0% |
| Hibrid me dy faza l≤3, λ = 0.01 / 0.1 / 1 / 10 | 0.218 / 0.220 / 0.215 / 0.183 | 0.70–0.78 | 22–27% | 3.2–4.2% | 0.076–0.080 | 15–17% |
| Hibrid me dy faza l≤2, λ=0.01 | 0.0859 | 0.487 ± 0.067 | 7.1 ± 1.2% | 1.21% | 0.054 | 5.7% |
| **Hibrid me dy faza l≤2, λ=0.1** (i zgjedhur) | **0.0857** | 0.498 ± 0.067 | **5.4 ± 3.0%** | 1.19% | 0.054 | **5.7%** |

### 9.2 Interpretimi

1. **Validimi zgjedh të njëjtën familje në të dyja fushat: hibridin me dy faza.** Te stuhia, të katër vlerat e λ janë të barabarta në validim (0.0640) dhe në test (J 0.19–0.21%). Te rryma unazore, validimi zgjedh l ≤ 2 me λ = 0.1 dhe e rendit të parin nga 36 trajnime/12 konfigurime, para MLP-së (0.0857 kundrejt 0.0920). Korrelacioni validim ↔ gabimi i J mbetet i fortë: ρ = 0.79 (stuhia, n = 27) dhe ρ = 0.82 (rryma, n = 36).
2. **Krahasuar me MLP-në, procedura nuk është kurrë dukshëm më e keqe dhe është shumë më e mirë kur baza përshtatet.** Te stuhia: J 15× më i vogël (0.19% kundrejt 2.93%), GC 20× (0.028 kundrejt 0.558), faza e driftit 28×, gjithmonë në 3/3 seed. Te rryma unazore: J 0.72× (5.4% kundrejt 7.5%), profili i pasqyrimit 0.75×, GC i barabartë (0.99×), faza e driftit 1.27× më keq. Asnjë diferencë jashtë bazës s'është domethënëse me 3 seed (Mann–Whitney p ≥ 0.10), prandaj duhet thënë "të paktën po aq mirë sa MLP-ja", jo "më mirë".
3. **Trajnimi me dy faza është elementi vendimtar, jo rregullimi.** λ nga 0.01 deri në 10 nuk ka pothuajse asnjë efekt brenda bazës, dhe nga 0.01 në 0.1 asnjë efekt jashtë saj. Paqëndrueshmëria e hibridit të njëkohshëm (J 4–42%) zhduket: shpërndarja mbi seed-e (± 3.0%) është tani sa ajo e MLP-së (± 2.3%).
4. **Shkalla l duhet zgjedhur me validim edhe brenda hibridit.** Jashtë bazës, për harmonikët vetëm fiton l ≤ 3, kurse për hibridin l ≤ 2 (J 5.4% kundrejt 22–27%). Një bazë më e pasur, por e gabuar, i lë MLP-së më pak hapësirë dhe ngurtëson më shumë strukturë të gabuar në fazën e parë.
5. **Kufiri real mbetet jashtë bazës.** Me procedurën e zgjedhur, J 5.4% dhe GC 0.50 R_E janë ende larg fushës së vërtetë (1e-6 dhe 3e-4). Ky është numri që duhet raportuar.

### 9.3 Procedura përfundimtare për punimin

1. Boris me fazë ekzakte brenda trajnimit.
2. K nga kriteri N_c, ose kurrikula e segmenteve.
3. Model B = B_dipol + ∇Φ_l + curl A_θ, i trajnuar me dy faza (baza → baza + MLP).
4. Shkalla l dhe λ zgjidhen me humbjen e validimit në elektrone të veçanta.

Kjo procedurë fiton ose barazon në të dyja fushat. Figura: `fig9_one_procedure`.

## 10. Krahasimi jashtë bazës me 10 seed dhe protokolli "më i miri nga k sipas validimit"

U shtuan 7 seed (3–9) për dy modelet kryesore jashtë bazës: MLP dhe hibridin me dy faza l ≤ 2, λ = 0.1, me K = 64 dhe Boris me fazë ekzakte. Testi: Mann–Whitney dypalësh, interval besimi bootstrap 95% për raportin e mesatareve (10 000 rimostrime) dhe Cliff's δ (−1 do të thotë se hibridi është gjithmonë më i ulët, pra më i mirë).

### 10.1 Krahasimi i drejtpërdrejtë (10 kundrejt 10 seed)

| Metrika | Hibrid me dy faza | MLP | Raporti [IB 95%] | Cliff's δ | p |
|---|---|---|---|---|---|
| Gabimi J | 7.3 ± 4.0% | 8.0 ± 1.9% | 0.92 [0.63, 1.26] | −0.16 | 0.57 |
| GC 10× [R_E] | 0.488 ± 0.092 | 0.489 ± 0.044 | 1.00 [0.87, 1.12] | 0.06 | 0.85 |
| Gabimi μ | 1.27% | 1.27% | 1.00 [0.84, 1.18] | −0.04 | 0.91 |
| Gabimi L_gc | 0.0303 | 0.0283 | 1.07 [0.92, 1.23] | 0.34 | 0.21 |
| Faza e driftit [rad] | 0.0537 ± 0.0020 | 0.0424 ± 0.0006 | **1.27 [1.23, 1.29]** | **+1.00** | **0.0002** |
| Gabimi i profilit të pasqyrimit | 5.9 ± 1.2% | 7.6 ± 0.4% | **0.78 [0.69, 0.88]** | **−0.80** | **0.003** |
| Humbja e validimit | 0.0879 | 0.0912 | 0.96 [0.92, 1.02] | −0.50 | 0.064 |

**Korrigjim i përfundimit të seksionit 9:** me 3 seed hibridi dukej 28% më i mirë në J (5.4% kundrejt 7.5%). Me 10 seed diferenca bie në 8% dhe nuk është domethënëse; seed-et e para ishin të favorshme. Me një seed të rastit, dy modelet janë ekuivalente në J, GC dhe μ. Por kanë profil të ndryshëm gabimesh:
- hibridi e mëson më mirë strukturën paralele të fushës (profili i pasqyrimit 22% më mirë, në mënyrë konsistente);
- MLP-ja e jep më mirë driftin (faza e driftit 27% më e vogël, në të 10 seed-et).

Shpjegimi i mundshëm, i patestuar ende: baza l ≤ 2 imponon gradientë tërthorë me strukturë të gabuar për rrymën unazore, dhe drifti varet pikërisht nga ∇B tërthor. Hibridi është edhe më i paqëndrueshëm mbi seed-e (σ e J 4.0% kundrejt 1.9%).

### 10.2 Zgjedhja e seed-it me validim

Brenda dy modeleve, humbja e validimit parashikon gabimin e J me ρ = 0.59 (p = 0.006, n = 20); mbi të 50 trajnimet jashtë bazës, ρ = 0.89 (p = 3e-18). Për k = 1–5 seed të trajnuar, mbahet ai me validimin më të ulët. Vlerat janë mesatare mbi të gjitha kombinimet e mundshme nga 10 seed-et (`outputs/best_of_k_prc.csv`, `fig10_best_of_k`).

| Protokolli | J (mesatarja) | J (percentili 90) | GC 10× | Faza e driftit | Profili i pasqyrimit |
|---|---|---|---|---|---|
| Hibrid, 1 seed | 7.3% | 12.2% | 0.488 | 0.054 | 5.9% |
| MLP, 1 seed | 8.0% | 9.9% | 0.489 | 0.042 | 7.6% |
| **Hibrid, më i miri nga 3** | **4.6%** | **5.1%** | 0.431 | 0.052 | 5.3% |
| MLP, më i miri nga 3 | 8.3% | 11.5% | 0.456 | 0.042 | 7.3% |
| Hibrid, më i miri nga 5 | 4.4% | 5.1% | 0.392 | 0.052 | 5.0% |
| Bashkësi 3 hibrid + 3 MLP, më i miri sipas validimit | 4.6% | 5.1% | 0.429 | 0.052 | 5.3% (hibridi zgjidhet në 99% të rasteve) |

Te hibridi, zgjedhja me validim funksionon: me 3 seed gabimi i J bie nga 7.3% në 4.6% dhe bishti i keq nga 12.2% në 5.1%. Te MLP-ja nuk ndihmon (8.0% → 8.3%), sepse validimi i saj ndryshon pak dhe lidhet dobët me gabimin në test. Faza e driftit e hibridit mbetet ~24% më e keqe edhe pas zgjedhjes.

Dy kufizime: (i) vlerat e "më i miri nga k" janë pritje të llogaritura mbi të njëjtat 10 seed, jo eksperimente të pavarura; (ii) pas zgjedhjes, krahasimi me MLP-në nuk ka test të pavarur statistikor. Një konfirmim i pastër do të kërkonte grupe të reja seed-esh të ndara.

### 10.3 Përfundimi për procedurën (përditëson 9.3)

Procedura është: Boris me fazë ekzakte → K nga N_c → hibrid me dy faza → l dhe λ me validim → **3 seed, mbahet ai me validimin më të ulët**. Rezultatet:
- **brenda bazës:** J 0.19% dhe GC 0.028, 15–20× më mirë se MLP-ja;
- **jashtë bazës:** J 4.6% (pritje), kundrejt 8.0–8.3% për MLP-në, por me fazë drifti ~24% më të keqe.

Ky kompromis duhet raportuar hapur. Nëse qëllimi kryesor është faza e driftit (Φ), MLP-ja mbetet zgjedhja më e mirë jashtë bazës.

## 11. Konfirmimi i pavarur dhe shkaku i fazës së driftit

### 11.1 Grupe të pavarura "më i miri nga 3"

U trajnuan 12 seed krejt të rinj (10–21) për secilin model jashtë bazës: MLP dhe hibrid me dy faza l ≤ 2, λ = 0.1, me K = 64 dhe fazë ekzakte. Seed-et u ndanë në 4 grupe të veçanta {10–12}, {13–15}, {16–18}, {19–21}. Nga çdo grup u mbajt modeli me humbjen e validimit më të ulët. Asnjë seed nuk ripërdoret, dhe fusha e vërtetë nuk përdoret në zgjedhje (`outputs/independent_best_of_3.csv`).

| Metrika (4 modele të zgjedhura për secilën metodë) | Hibrid | MLP | Raporti | Hibridi fiton (sipas grupit) | Mann–Whitney p |
|---|---|---|---|---|---|
| Gabimi J | 4.9 ± 1.6% | 8.7 ± 1.7% | 0.56 | 4/4 | 0.057 |
| GC 10× [R_E] | 0.453 | 0.446 | 1.02 | 2/4 | 1.00 |
| Gabimi μ | 1.20% | 1.26% | 0.95 | 2/4 | 0.49 |
| Faza e driftit [rad] | 0.0518 | 0.0416 | 1.24 | 0/4 | 0.029 |
| Gabimi i profilit të pasqyrimit | 5.5% | 8.4% | 0.65 | 4/4 | 0.029 |

Me 4 kundrejt 4, p minimale e mundshme është 0.029. Parashikimi kombinatorik i seksionit 10.2 ishte J 4.6% kundrejt 8.3%; konfirmimi i pavarur jep 4.9% kundrejt 8.7%, pra parashikimi qëndron.

### 11.2 Të gjitha 22 seed-et bashkë (një seed i rastit)

| Metrika | Hibrid (n = 22) | MLP (n = 22) | Raporti [IB 95%] | Cliff's δ | p |
|---|---|---|---|---|---|
| Gabimi J | 6.5 ± 3.2% | 8.4 ± 2.2% | **0.77 [0.61, 0.96]** | −0.46 | **0.009** |
| GC 10× | 0.479 | 0.489 | 0.98 [0.89, 1.07] | −0.09 | 0.63 |
| Gabimi μ | 1.30% | 1.30% | 1.00 [0.89, 1.14] | −0.17 | 0.34 |
| Gabimi L_gc | 0.0294 | 0.0279 | 1.05 [0.96, 1.16] | 0.19 | 0.29 |
| Faza e driftit | 0.0532 | 0.0421 | **1.26 [1.25, 1.28]** | +1.00 | **1e-8** |
| Profili i pasqyrimit | 5.9% | 7.9% | **0.75 [0.69, 0.82]** | −0.85 | **2e-6** |
| Humbja e validimit | 0.0877 | 0.0916 | 0.96 [0.93, 0.99] | −0.46 | 0.009 |

**Korrigjim i përfundimit të seksionit 10.1:** me 10 seed diferenca në J (−8%) nuk dallohej nga zhurma. Me 22 seed del se hibridi është realisht ~23% më i mirë në J edhe me një seed të vetëm (p = 0.009). Mësimi metodologjik: me shpërndarje kaq të madhe mbi seed-e (σ ≈ 3% për J), 3 apo 10 seed nuk mjaftojnë për diferenca të këtij rendi.

Brenda hibridit, validimi parashikon J me ρ = 0.58 (p = 0.005, n = 22); te MLP-ja jo (ρ = −0.35). Pritja "më i miri nga 3" mbi 22 seed: hibrid J 4.9% (percentili 90: 7.9%), MLP 8.9% (11.5%). Te seed-et e reja 10–21 lidhja validim ↔ J brenda hibridit ishte më e dobët (ρ = 0.42, p = 0.17), dhe një seed i rastit dha tashmë 5.8%. Pra pjesa më e madhe e fitimit vjen nga vetë hibridi, kurse zgjedhja e seed-it shton më pak dhe në mënyrë më pak të qëndrueshme.

### 11.3 Shkaku i fazës më të keqe të driftit

Drifti magnetik është shuma e driftit të gradientit (∝ b × ∇⊥|B|) dhe driftit të lakimit (∝ b × κ_b, κ_b = (b·∇)b). Të dyja u matën për çdo model mbi pikat e trajektoreve të testit dhe u krahasuan me fushën e vërtetë (`evaluation/drift_diagnostics.py`, 22 + 22 seed):

| | Gabimi relativ i ∇⊥\|B\| | Gabimi relativ i κ_b | Faza e driftit |
|---|---|---|---|
| MLP | 23.4 ± 0.5% | 6.6 ± 0.4% | 0.0421 |
| Hibrid | 25.6 ± 0.8% | 5.2 ± 1.1% | 0.0532 |
| Mann–Whitney p | 2e-8 | 6e-5 | 1e-8 |
| Korrelacioni me fazën e driftit (n = 44) | ρ = 0.76, p = 3e-9 | ρ = −0.49 | – |

Hibridi e gabon më shumë gradientin tërthor të |B|, dhe ky gabim shpjegon fazën e driftit (ρ = 0.76). Lakimin e vijave e jep më mirë, në përputhje me profilin më të mirë të pasqyrimit. Interpretimi: baza harmonike l ≤ 2 imponon gradientë tërthorë me formë vakumi, ndërsa rryma unazore brenda zonës krijon gradientë që s'kanë atë formë. Vlen gjithashtu të vihet re se ∇⊥|B| gabohet ~23% edhe nga MLP-ja: kjo është pjesa e fushës që trajektoret e shkurtra e kufizojnë më dobët.

### 11.4 Përfundimi i përditësuar jashtë bazës

Hibridi me dy faza e mëson më mirë strukturën paralele të fushës. Rezultatet: J −23% me një seed (p = 0.009) dhe −44% kur mbahet më i miri nga 3 (konfirmuar në grupe të pavarura, 4/4); profili i pasqyrimit −25% deri −35%. Me kosto: faza e driftit +24–26%, për shkak të gradientit tërthor. GC dhe μ janë të barabartë. Procedura e seksionit 10.3 mbetet e vlefshme me këtë kompromis të raportuar hapur.

## 12. A mund të hiqet penaliteti i driftit te hibridi?

Qëllimi: të ulet gabimi i ∇⊥|B| (dhe me të faza e driftit) te hibridi me dy faza, pa humbur avantazhin brenda bazës. U testuan, në të dyja fushat me 3 seed (seed 0–2, K=48/64, fazë ekzakte):
- (a) bazë vetëm l = 1 (fushë uniforme) + MLP;
- (b) bazë l ≤ 2 me penalitet λ_b·|c_{l=2}|² mbi termat e gradientit (λ_b = 0.1 dhe 1);
- (c) fazë e parë më e shkurtër (25 dhe 50 epoka në vend të 100);
- (d) rregullim MLP sa i MLP-së bazë (λ_reg = 0.001 në vend të 0.1).

### 12.1 Rezultatet (seed 0–2)

| Konfigurimi | Stuhia: J / GC 10× / faza e driftit | Rryma unazore: validim / J / GC 10× / faza e driftit / ∇⊥\|B\| |
|---|---|---|
| MLP | 2.93% / 0.558 / 0.0117 | 0.0920 / 7.5% / 0.504 / **0.0420** / **23.4%** |
| Hibrid i njëkohshëm (faza e parë 0) | 2.97% / 0.421 / 0.0140 | 0.1178 / 20.4 ± 19.5% / 0.579 / **0.0425** / 24.8% |
| Hibrid me dy faza, faza e parë 100 (referenca) | **0.21% / 0.029 / 0.0005** | 0.0857 / 5.4% / 0.498 / 0.0535 / 25.6% |
| (a) bazë l = 1 | 5.91% / 0.566 / 0.0136 | 0.1126 / 18.3% / 0.611 / 0.0564 / 28.4% |
| (b) penalitet l = 2, λ_b = 0.1 | 0.35% / 0.045 / 0.0007 | 0.0851 / 8.0% / 0.437 / 0.0544 / 25.8% |
| (b) penalitet l = 2, λ_b = 1 | 0.93% / 0.221 / 0.0048 | 0.1014 / 13.1% / 0.589 / 0.0548 / 26.5% |
| (c) faza e parë 25 | 0.93% / 0.212 / 0.0041 | 0.0919 / 16.0% / 0.686 / 0.0487 / 25.1% |
| (c) faza e parë 50 | 0.43% / 0.122 / 0.0009 | 0.0838 / 4.8 ± 0.7% / 0.412 / 0.0521 / 25.2% (mesatare mbi 10 seed) |
| (d) λ_reg = 0.001 | 0.21% / 0.029 / 0.0005 | 0.0859 / 7.4% / 0.486 / 0.0536 / – |

### 12.2 Konfigurimi me fazë të parë 50: 10 seed

Me 3 seed, faza e parë 50 dukej më e mira dhe më e qëndrueshmja jashtë bazës (J 4.8 ± 0.7%), dhe validimi e zgjodhi (0.0838, më e ulëta nga të gjitha konfigurimet). U shtuan 7 seed (3–9):

| Metrika | Faza e parë 50 (n = 10) | Faza e parë 100 (n = 22) | p | MLP (n = 22) | Raporti ndaj MLP [IB 95%] | p |
|---|---|---|---|---|---|---|
| Gabimi J | 6.4 ± 4.1% | 6.5 ± 3.2% | 0.67 | 8.4 ± 2.2% | 0.75 [0.49, 1.07] | 0.059 |
| GC 10× | 0.426 | 0.479 | 0.11 | 0.489 | **0.87 [0.78, 0.97]** | **0.019** |
| Faza e driftit | 0.0522 | 0.0532 | 0.43 | 0.0421 | **1.24 [1.20, 1.29]** | **1e-5** |
| Profili i pasqyrimit | 5.6% | 5.9% | 0.79 | 7.9% | **0.71 [0.66, 0.76]** | **1e-5** |
| Validimi | 0.0856 | 0.0877 | 0.28 | 0.0916 | 0.94 [0.90, 0.98] | 0.004 |

Avantazhi i 3 seed-eve u zhduk përsëri: me 10 seed, faza e parë 50 dhe 100 janë ekuivalente në çdo metrikë. Kjo është hera e tretë që 3 seed japin përfundim të gabuar në këtë sistem. Prandaj **çdo krahasim në punim duhet të ketë ≥ 10 seed.**

### 12.3 Përfundimet

1. **Hipoteza se termat l = 2 të bazës e shkaktojnë penalitetin e driftit hidhet poshtë.** Bazë l = 1 dhe penaliteti mbi l = 2 nuk e ulin gabimin e ∇⊥|B|; e rrisin (26–28%) dhe e përkeqësojnë J në të dyja fushat.
2. **Mekanizmi i mbështetur (jo ende i provuar): faza e parë.** Faza e driftit rritet në mënyrë monotone me gjatësinë e fazës së parë: 0.042 (0 epoka) → 0.049 (25) → 0.052 (50) → 0.054 (100). Interpretimi është se trajnimi vetëm me bazë ngurtëson strukturën e gradientit, të cilën MLP-ja nuk e korrigjon dot më pas. Rregullimi nuk ka ndikim (λ_reg 0.001 dhe 0.1 japin të njëjtën fazë drifti). Buxheti total (300 epoka) dhe kriteri i ndalimit (pa ndalim të hershëm) mbetën të njëjtë, por me fazë të parë më të gjatë ndryshojnë dy faktorë të tjerë: MLP-ja merr më pak epoka (300 − faza e parë) dhe hyn kur shpejtësia e mësimit sipas kosinusit është tashmë më e ulët. Derisa këta faktorë të ndahen (detyra 4 në seksionin 13), përfundimi formulohet si mekanizëm i mbështetur nga eksperimentet. **Përditësim (seksioni 14.1): kontrolli u krye. Faza e parë konfirmohet si shkak i penalitetit, por efekti sillet si shkallë, jo si rregullator i vazhdueshëm.**
3. **Kompromisi është i vërtetë dhe s'ka konfigurim që fiton në të dyja aksen jashtë bazës** (`fig11_tradeoff`). Pa fazë të parë, drifti del si te MLP-ja (0.042), por J është shumë i paqëndrueshëm (σ 19.5%). Me fazë të parë ≥ 50, J është më i qëndrueshëm dhe më i mirë se te MLP-ja, kurse drifti del ~24% më keq. MLP-ja ka driftin më të mirë dhe J-në më të keq ndër konfigurimet e qëndrueshme.
4. **Brenda bazës nuk ka kompromis:** faza e parë 100 jep gjithçka më mirë (J 0.21%, GC 0.029, drift 0.0005). Faza e parë më e shkurtër dëmton në mënyrë monotone (50: J 0.43%; 25: 0.93%).
5. **Për punimin:** procedura e seksionit 10.3 mbetet, me gjatësinë e fazës së parë si hiperparametër që zgjidhet me validim. Kompromisi J ↔ drift jashtë bazës raportohet si kufizim, me figurën 11. Kur drifti (Φ) është prioritar, rekomandohet MLP-ja.

## 13. Hapat e ardhshëm

Eksperimentet kryesore janë mbyllur. Ajo që mbetet para shkrimit janë katër detyra përfundimtare:

1. **Përsëritja e kriterit N_c dhe e kurrikulës me Boris me fazë ekzakte** (dhe në fushën jashtë bazës), që gjetja kryesore 2 të qëndrojë me integruesin përfundimtar. Me ≥ 3 seed për pikë rreth kufirit.
2. **Neural ODE i pastrukturuar** (MLP 6D + RK4) si baseline, për të treguar ç'humbet pa strukturën Boris (energjia, μ).
3. **Appendix teorik:** nxjerrja e N_c = 1/(2δ) dhe e devijimit të fazës së Boris (Ωdt)²/12.
4. **Kontrolli i mekanizmit të fazës së parë.** Qëllimi: të ndahet efekti i ngurtësimit të bazës nga dy faktorët që sot ndryshojnë njëkohësisht me gjatësinë e fazës së parë, pra numri i epokave të MLP-së dhe shpejtësia e mësimit me të cilën ajo nis.
   - *Dizajni:* faza e dytë merr gjithmonë të njëjtin numër epokave (p.sh. 300) dhe një kurbë të re kosinusi të shpejtësisë së mësimit, që nis nga vlera maksimale për të gjithë parametrat, pavarësisht nga gjatësia e fazës së parë (0, 25, 50, 100). Buxheti total ndryshon atëherë vetëm nga vetë faza e parë, dhe kjo raportohet. Kriteri i ndalimit mbetet i njëjtë (pa ndalim të hershëm).
   - *Kontroll shtesë:* MLP vetëm me 200 dhe 300 epoka, për të matur sa varet drifti nga numri i epokave të MLP-së, pa bazë fare.
   - *Fusha dhe seed-et:* jashtë bazës (rryma unazore), ≥ 10 seed për konfigurim; mundësisht edhe brenda bazës.
   - *Si lexohet rezultati:* nëse faza e driftit vazhdon të rritet me gjatësinë e fazës së parë kur faza e dytë është e barabartë, mekanizmi i ngurtësimit konfirmohet dhe mund të paraqitet si shkak. Nëse rritja zhduket, penaliteti i driftit vinte nga trajnimi më i shkurtër ose nga shpejtësia më e ulët e MLP-së, dhe zgjidhja është thjesht një plan trajnimi më i mirë. Në të dyja rastet përfundimi i figurës 11 rishikohet.
5. **Shkrimi:** metodologjia, figurat 1, 5, 6, 7, 9, 10, 11 dhe tabelat 3, 5, 7.4, 8.2, 11.2, 12.2.

### Ide për diskutimin shkencor (jo ende përfundim)

Gjatësia e fazës së parë mund të jetë **hiperparametër strukturor i metodës**, jo thjesht parametër teknik trajnimi. Interpretimi: ajo rregullon sa nga paragjykimi i bazës fizike mbijeton në zgjidhjen përfundimtare. Kështu vepron si një rregullator i vazhdueshëm ndërmjet një zgjidhjeje të dominuar nga baza (më e mirë për strukturën përgjatë vijave të fushës, pra për J dhe pikat e pasqyrimit) dhe një zgjidhjeje të dominuar nga të dhënat (më e mirë për gradientin tërthor, pra për driftin dhe Φ). Nëse detyra 4 e konfirmon mekanizmin, kjo mund të jetë pjesë me vlerë e kontributit të PINN-4.

Pozicionimi i nevojshëm: ideja që pikënisja e optimizimit përcakton zgjidhjen e gjetur është e njohur (ngrohja nga një model fizik, kurrikula, identifikimi "grey-box" me dy hapa). Risia nuk do të ishte ideja në vetvete, por tregimi i matshëm që në një sistem me gjirim ky parametër ndan dy invariante fizike, J dhe Φ.


## 14. Rezultatet e katër detyrave përfundimtare

Të gjitha eksperimentet u ekzekutuan në një radhë të vetme me 102 trajnime, me Boris me fazë ekzakte. Statistikat janë Mann–Whitney dypalësh. Fusha jashtë bazës është rryma unazore e seksionit 8, K = 64.

### 14.1 Detyra 4: kontrolli i mekanizmit të fazës së parë

**Dizajni.** Faza e dytë merr gjithmonë 300 epoka, me optimizues të ri dhe kurbë të re kosinusi që nis nga shpejtësia maksimale e mësimit. Buxheti total është 300 + faza e parë; kriteri i ndalimit (pa ndalim të hershëm) mbetet i njëjtë. Faza e parë = 0 është hibridi i njëkohshëm. Për krahasim: MLP me 200 dhe 300 epoka. Për çdo konfigurim 10 seed (MLP 300: 22).

| Konfigurimi | Faza e driftit | Gabimi J | GC 10× | Profili i pasqyrimit | Validimi |
|---|---|---|---|---|---|
| Pa fazë të parë (i njëkohshëm) | **0.0422 ± 0.0014** | 19.2 ± 18.5% | 0.597 | 12.9% | 0.132 |
| Faza e parë 25, rinisje | 0.0492 ± 0.0010 | 7.6 ± 3.7% | 0.538 | 6.4% | 0.0835 |
| Faza e parë 50, rinisje | 0.0518 ± 0.0018 | 8.4 ± 3.5% | 0.471 | 6.9% | 0.0888 |
| Faza e parë 100, rinisje | 0.0503 ± 0.0012 | **4.8 ± 1.3%** | 0.472 | **5.7%** | 0.0993 |
| Faza e parë 50, plani origjinal | 0.0522 ± 0.0032 | 6.4 ± 4.1% | 0.426 | 5.6% | 0.0856 |
| Faza e parë 100, plani origjinal (n = 22) | 0.0532 ± 0.0018 | 6.5 ± 3.2% | 0.479 | 5.9% | 0.0877 |
| MLP, 200 epoka | 0.0396 ± 0.0007 | 16.5 ± 2.3% | 0.629 | 12.5% | 0.0966 |
| MLP, 300 epoka (n = 22) | 0.0421 ± 0.0007 | 8.5 ± 2.2% | 0.489 | 7.9% | 0.0916 |

**Çfarë tregon kontrolli.**
1. **Faza e parë është shkaku i penalitetit të driftit.** Me fazë të dytë identike, çdo fazë e parë prej 25, 50 ose 100 epokash e rrit gabimin e driftit me 17%, 23% dhe 19% ndaj hibridit të njëkohshëm (p = 2e-4 për secilën, 10/10 seed). Numri i epokave të MLP-së dhe shpejtësia e mësimit me të cilën ajo nis nuk e shpjegojnë këtë.
2. **Efekti është më shumë shkallë sesa rregullator.** Ndërmjet 25 dhe 100 epokave drifti ndryshon pak dhe jo në mënyrë monotone (Spearman ρ = 0.34, p = 0.06). Monotonia e dukshme e seksionit 12 vinte pjesërisht nga ngatërrimi. Te faza e parë 100, rinisja e ul driftin nga 0.0532 në 0.0503 (p = 4e-4). Nga penaliteti origjinal ndaj hibridit të njëkohshëm (0.0110 rad), rreth një e katërta (0.0029) vinte nga plani i trajnimit dhe rreth tre të katërtat (0.0081) nga vetë faza e parë.
3. **Edhe te MLP-ja ka kompromis J ↔ drift gjatë trajnimit.** Me më shumë epoka J përmirësohet (16.5% → 8.5%, p = 1e-5), kurse drifti përkeqësohet (0.0396 → 0.0421, p = 9e-6). Penaliteti i hibridit është megjithatë shtesë: me J të krahasueshëm (7.6–8.4%), hibridet me fazë të parë kanë drift 0.049–0.052, kundrejt 0.042 për MLP-në.
4. **Kujdes për validimin:** varianti me fazë të parë 100 dhe rinisje ka J-në më të mirë dhe më të qëndrueshme (4.8 ± 1.3%), por validimin më të keq ndër hibridet me dy faza (0.0993). Këtu humbja e validimit nuk e rendit saktë modelin, prandaj zgjedhja me validim nuk duhet paraqitur si e pagabueshme.

**Formulimi për punimin.** Penaliteti i driftit shkaktohet nga ekzistenca e një faze të trajnuar vetëm me bazë: kjo konfirmohet me kontroll që mban fazën e dytë identike. Gjatësia e asaj faze ndikon kryesisht në qëndrueshmërinë e J, jo në drift. Ideja e "hiperparametrit strukturor" mbetet e vlefshme, por në formë më të saktë. Prania e fazës së parë është vendim strukturor që e zhvendos zgjidhjen drejt strukturës së bazës (më mirë J dhe pikat e pasqyrimit, më keq gradienti tërthor dhe drifti), ndërsa gjatësia e saj është rregullim dytësor.

### 14.2 Detyra 2: Neural ODE pa strukturë fizike

Modeli: dr/dt = v, dv/dt = f_θ(r, v) (MLP tanh 3 × 64, dalja e shkallëzuar me 1/ε dhe nisur nga zero), integrim RK4 me të njëjtin hap, të njëjtin segmentim MIC dhe të njëjtat 300 epoka. 5 seed për secilën fushë.

| | Humbja e trajnimit | Validimi | Gabimi i energjisë pas 1 vrojtimi (t = 0.02) | Gabimi i energjisë në t = 14 (1×) | Gabimi i energjisë në t = 140 (10×) |
|---|---|---|---|---|---|
| Neural ODE, stuhia | 2.05 | 7.23 | > 10% për 8/8 elektrone | ~100% (mediana) | ~1e5 (mesatarja) |
| Neural ODE, rryma unazore | 0.99 | 4.32 | > 10% për 7/8 elektrone | 77% (mediana) | ~2e6 (mesatarja) |
| Çdo model me Boris | 0.032–0.037 | 0.064–0.13 | ~1e-14 | ~1e-14 | ~3e-14 |

Me të njëjtin buxhet, Neural ODE pa strukturë nuk e mëson gjirimin: humbja e trajnimit mbetet 30–60 herë mbi atë të modeleve me Boris. Pa ruajtje strukturore të energjisë, trajektoret largohen menjëherë. Në horizontin 10× gabimet e GC, J dhe μ dalin të pakuptimta (elektronet shpërthejnë). Kufizim që duhet thënë në punim: ky është një baseline me të njëjtin buxhet dhe pa inxhinierim shtesë. Një Neural ODE me kurrikulë, trajnim më të gjatë ose normalizim të posaçëm mund të dalë më mirë. Rezultati tregon vlerën e strukturës Boris me buxhet të barabartë, jo kufirin e çdo Neural ODE të mundshëm.

### 14.3 Detyra 1: kriteri i fazës me integruesin përfundimtar

U përsëritën 3 forca stuhie × 4 vlera K rreth kufirit (N/N_c = 0.70, 0.84, 1.04, 1.39) × 3 seed = 36 trajnime me Boris me fazë ekzakte (`outputs/threshold_xp/`).

**Forma pa parametra (e re).** Për çdo segment uniform të trajektoreve të trajnimit pa zhurmë, mospërputhja e fazës që modeli fillestar (dipol) akumulon është Δφ₀ = (1/ε)∫(|B_vërtetë| − |B_dipol|)dt. Si tregues merret mediana mbi segmentet (`evaluation/phase_criterion.py`, figura `fig13_phase_criterion`).

| Bashkësia | Trajnime | Pragu më i mirë | Saktësia me 2.83 rad | Saktësia me π |
|---|---|---|---|---|
| Boris standard (seksioni 5) | 52 | 2.83 rad | 98.1% | 86.5% |
| **Boris me fazë ekzakte (e re, jashtë mostrës)** | 36 | 2.83 rad | **97.2%** | 80.6% |
| Të gjitha | 88 | 2.83 rad | 97.7% | 84.1% |

Rregulli N < N_c me δ ekuatoriale klasifikon 32/36 (89%) të trajnimeve të reja, pra forma pa parametra është më e saktë. Pragu 2.83 rad, i gjetur te trajnimet me Boris standard, parashikon trajnimet me fazë ekzakte pa asnjë rregullim. Kufiri është i njëjtë me të dy integruesit: stuhia 0.5 me K = 16 konvergjon (Δφ₀ = 2.80 rad), stuhia 1 me K = 32 dështon (2.84 rad). I vetmi rast i klasifikuar gabim në të dyja bashkësitë është stuhia 2 me K = 80 (Δφ₀ = 2.31 rad), ku një nga tre seed-et ngec pjesërisht (humbja 0.08 me integruesin e ri, 0.09 me të vjetrin).

**Në fushën jashtë bazës** (MLP, K = 24–64, 3 seed): të gjitha konvergjojnë (humbja 0.032–0.037). Kriteri jep Δφ₀ = 2.92, 2.18, 1.45 dhe 1.09 rad. K = 24 është pra 3% mbi pragun 2.83 dhe megjithatë konvergjon në 3/3. Kjo është brenda zonës kalimtare, por tregon se pragu nuk është konstante universale deri në shifrën e dytë: në një fushë asimetrike, ku δ ndryshon shumë përgjatë trajektores, ai duket pak më i lartë. Formulimi i saktë është prag ≈ 2.8–2.9 rad, rreth 0.9π.

**Pasoja për punimin.** Kriteri qëndron me integruesin përfundimtar dhe në një test jashtë mostrës. Forma pa parametra Δφ₀ duhet të jetë versioni kryesor në punim; forma N_c = 1/(2δ) mbetet si vlerësim i shpejtë.

### 14.4 Detyra 3: Appendix teorik

Teksti është te `APPENDIX_theory.md` (anglisht, prozë akademike). Përmban:
- **A.1:** devijimin e fazës së Boris η = (Ωdt)²/12. Vlera numerike është 3.31e-3 me Ωdt = 0.2, dhe faza e humbur 1.041 rad pas 50 gjirimesh, saktësisht sa matja. Përmban edhe pasojën për fushën e mësuar: gabimi paralel i bazës harmonike bie nga 0.45% në 0.08% me fazë ekzakte.
- **A.2:** kushtin e mbështjelljes së fazës. Termi i vazhdimësisë në fund të segmentit ka basen e saktë vetëm për |Δφ| < π. Termi mesatar i të dhënave, 1 − sin x/x, rritet deri në x* = 4.493 = 1.43π (rrënja e parë e tan x = x) dhe është konveks vetëm deri në x ≈ 2.08. Pragu i matur 2.83 rad bie pranë skajit të poshtëm të intervalit [π, 4.49]. Kjo sugjeron që defekti i vazhdimësisë, jo termi i të dhënave, vendos kur problemi humbet basen e saktë.

Appendix-i u plotësua pas trajnimeve me fazë ekzakte me dy fakte të seksionit 14.3: (i) riprodhimin jashtë mostrës (97.2%) dhe (ii) përjashtimin e fushës asimetrike (K = 24, 2.92 rad, konvergjon).

## 15. Gjendja para shkrimit

Të katër detyrat përfundimtare janë kryer. Përfundimet që hyjnë në punim:
1. **Boris me fazë ekzakte brenda trajnimit:** heq një devijim sistematik 0.33% që përndryshe kontaminon fushën e mësuar (Appendix A.1, seksioni 7.4).
2. **Kriteri i mbështjelljes së fazës:** Δφ₀ ≲ 2.8–2.9 rad për segment, i verifikuar në 88 trajnime me dy integrues (97.7%) dhe i shpjeguar teorikisht (Appendix A.2). Plus kufiri i poshtëm empirik i gjatësisë së segmentit (mbifitimi me K = 96) dhe kurrikula e segmenteve.
3. **Struktura e fushës:** modeli hibrid me dy faza, me shkallën dhe λ të zgjedhura me validim.
   - Brenda bazës: J 0.19%, 15–20× më mirë se MLP-ja.
   - Jashtë bazës: J −23% me një seed dhe −44% me më të mirin nga 3 (i konfirmuar në grupe të pavarura). Me kosto drifti +24–26%, i shkaktuar nga faza e parë (kontrolli 14.1).
4. **Kompromisi J ↔ drift** (figurat 11 dhe 12) si kufizim i raportuar hapur, me shkakun e identifikuar.
5. **Krahasimi me Neural ODE:** me buxhet të barabartë, struktura Boris është kusht për të mësuar fare (14.2).

Appendix-i u përditësua me dy faktet e 14.3. Mund të nisë teksti i metodologjisë, me figurat 1, 7, 9, 10, 11, 12, 13 dhe tabelat 7.4, 8.2, 11.2, 14.1, 14.3.
