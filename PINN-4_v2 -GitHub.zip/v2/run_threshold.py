"""Phase-wrapping threshold experiment: storm strength x K (uniform MIC, seed 0).
Predicted critical gyrations per segment: N_c = 1 / (2 dB/B), dB/B ~ b_s at L=4 equator."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
jobs = []
for storm, Ks in [(0.5, (12, 16, 24, 32)), (2.0, (32, 48, 64, 96)), (1.0, (16, 64))]:
    for K in Ks:
        d = "data/dataset.npz" if storm == 1.0 else f"data/dataset_storm{storm:g}.npz"
        jobs.append((f"thr_storm{storm:g}_K{K}", f"K={K} epochs=300 data={d}"))

def run(j):
    name, args = j
    if os.path.exists(f"outputs/threshold/{name}_s0.pt"): return
    with open(f"outputs/logs/{name}.log", "w") as f:
        subprocess.run(f"python3 -m training.run threshold/{name} uniform 0 {args}".split(),
                       stdout=f, stderr=subprocess.STDOUT)
os.makedirs("outputs/threshold", exist_ok=True)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("THRESHOLD DONE")
