"""
evaluation/evaluate.py -- long-horizon test (10x the training window) from
unseen initial conditions. Every model is integrated with the same Boris step
(DT_MODEL); diagnostics use the TRUE field so they measure physics, not the model.
"""
import numpy as np
import torch
from physics.fields import true_field_torch, true_field_np, dipole_torch
from physics.boris import boris_torch
from physics.invariants import mu, bounce_J, lshell_gc, drift_phase, guiding_centre
from models.field_net import CurlField
from training.mic import DT_MODEL


def load_field(path):
    ck = torch.load(path, weights_only=False)
    c = ck["cfg"]
    from training.mic import build_model
    m = build_model(c)
    m.load_state_dict(ck["state"]); m.eval()
    m.exact_phase = bool(c.get("exact_phase", False))   # evaluate with the integrator it was trained with
    return m, ck


@torch.no_grad()
def rollout(field, r0, v0, n_obs, sub):
    r = torch.tensor(r0); v = torch.tensor(v0)
    R, V = [r.numpy().copy()], [v.numpy().copy()]
    for k in range(1, n_obs * sub + 1):
        if getattr(field, "is_node", False):
            from models.node import rk4_step
            r, v = rk4_step(r, v, DT_MODEL, field)
        else:
            r, v = boris_torch(r, v, DT_MODEL, field, exact_phase=getattr(field, "exact_phase", False))
        if k % sub == 0:
            R.append(r.numpy().copy()); V.append(v.numpy().copy())
    return np.stack(R, 1), np.stack(V, 1)


def metrics(R, V, Rg, Vg, dt_obs, n_train):
    out = {}
    out["pos_rmse_1x"] = np.sqrt(np.mean(np.sum((R[:, :n_train] - Rg[:, :n_train]) ** 2, -1)))
    out["pos_rmse_10x"] = np.sqrt(np.mean(np.sum((R - Rg) ** 2, -1)))
    G, Gg = guiding_centre(R, V), guiding_centre(Rg, Vg)
    out["gc_rmse_1x"] = np.sqrt(np.mean(np.sum((G[:, :n_train] - Gg[:, :n_train]) ** 2, -1)))
    out["gc_rmse_10x"] = np.sqrt(np.mean(np.sum((G - Gg) ** 2, -1)))
    out["energy_drift"] = np.abs(np.sum(V * V, -1) - np.sum(Vg[:, :1] ** 2, -1)).max()
    m, mg = mu(R, V, dt_obs), mu(Rg, Vg, dt_obs)
    out["mu_err"] = np.mean(np.abs(m - mg) / mg)
    je = []
    for p in range(len(R)):
        J, Jg = bounce_J(R[p], V[p], dt_obs), bounce_J(Rg[p], Vg[p], dt_obs)
        n = min(len(J), len(Jg))
        je.append(np.mean(np.abs(J[:n] - Jg[:n]) / Jg[:n]) if n else np.nan)
    out["J_err"] = float(np.nanmean(je))
    out["L_err"] = np.mean(np.abs(lshell_gc(R, V) - lshell_gc(Rg, Vg)))
    out["drift_phase_err"] = np.mean(np.abs(drift_phase(R, V)[:, -1] - drift_phase(Rg, Vg)[:, -1]))
    return out


def evaluate_field(field, data):
    dt_obs = float(data["dt_obs"]); sub = int(round(dt_obs / DT_MODEL))
    Rg, Vg = data["test_r"], data["test_v"]
    R, V = rollout(field, Rg[:, 0], Vg[:, 0], Rg.shape[1] - 1, sub)
    return metrics(R, V, Rg, Vg, dt_obs, data["obs_r"].shape[1]), (R, V)


REFERENCE_FIELDS = {"dipole_only": dipole_torch, "true_field": true_field_torch}
