"""
evaluation/field_diagnostics.py -- where does the learned field go wrong?

For each checkpoint, on training and test trajectory points:
  e_par  = <|dB . b|>         error along B  -> gyro-frequency, mirror points, J
  e_perp = <|dB - (dB.b) b|>  error across B -> weakly felt by a gyrating particle
both relative to the size of the true storm field in the same component.
Per test electron: J error vs distance from the training set
(longitude gap to the nearest training electron, |dL|, pitch angle).
Usage: python -m evaluation.field_diagnostics name1 name2 ...  (names without _sN)
"""
import sys, glob, json
import numpy as np, pandas as pd, torch
from scipy.stats import spearmanr
from evaluation.evaluate import load_field, rollout
from physics.fields import true_field_torch, dipole_torch
from physics.invariants import bounce_J

data = dict(np.load("data/dataset.npz"))


def components(field, R):
    r = torch.tensor(R.reshape(-1, 3))
    with torch.no_grad():
        Bt = true_field_torch(r); b = Bt / Bt.norm(dim=-1, keepdim=True)
        dS = Bt - dipole_torch(r); dB = field(r) - Bt
    par = lambda x: (x * b).sum(-1).abs()
    perp = lambda x: (x - (x * b).sum(-1, keepdim=True) * b).norm(dim=-1)
    return dict(e_par=par(dB).mean().item(), e_perp=perp(dB).mean().item(),
                rel_par=(par(dB).mean() / par(dS).mean()).item(),
                rel_perp=(perp(dB).mean() / perp(dS).mean()).item())


def mirror_profile_err(field, data, n_pts=1300):
    """Median over test electrons of the error in the mirror-ratio profile
    B(s)/B(s0) along ~1 true bounce, relative to its excursion (B/B0 - 1).
    This, not the mean |dB|, controls mirror points and therefore J."""
    errs = []
    for q in range(len(data["test_r"])):
        r = torch.tensor(data["test_r"][q, :n_pts])
        with torch.no_grad():
            Bm = field(r).norm(dim=-1).numpy(); Bt = true_field_torch(r).norm(dim=-1).numpy()
        exc = Bt / Bt[0] - 1; sel = exc > 0.02
        errs.append(np.median(np.abs(Bm / Bm[0] - Bt / Bt[0])[sel] / exc[sel]))
    return float(np.mean(errs))


def lon_gap(phi_test, phi_train):
    d = np.abs((phi_test[:, None] - phi_train[None, :] + np.pi) % (2 * np.pi) - np.pi)
    return d.min(1)


if __name__ == "__main__":
    rows, per = [], []
    tp, trp = data["test_params"], data["train_params"]
    gap = np.degrees(lon_gap(tp[:, 2], trp[:, 2]))
    dL = np.abs(tp[:, 0][:, None] - trp[:, 0][None, :]).min(1)
    Rg, Vg = data["test_r"], data["test_v"]
    for name in [a for a in sys.argv[1:] if not a.startswith("--")]:
        for p in sorted(glob.glob(f"outputs/{name}_s*.pt")):
            f, ck = load_field(p)
            tr, te = components(f, data["train_r"]), components(f, data["test_r"])
            rows.append(dict(method=name, ckpt=p, mirror_profile_err=mirror_profile_err(f, data),
                             **{f"train_{k}": v for k, v in tr.items()},
                             **{f"test_{k}": v for k, v in te.items()}))
            if name == sys.argv[1] and "--per" in sys.argv:
                R, V = rollout(f, Rg[:, 0], Vg[:, 0], Rg.shape[1] - 1, 5)
                for q in range(len(Rg)):
                    J, Jg = bounce_J(R[q], V[q], 0.02), bounce_J(Rg[q], Vg[q], 0.02); n = min(len(J), len(Jg))
                    per.append(dict(ckpt=p, electron=q, J_err=np.mean(np.abs(J[:n] - Jg[:n]) / Jg[:n]),
                                    lon_gap_deg=gap[q], dL=dL[q], L=tp[q, 0], alpha=tp[q, 1],
                                    e_par=components(f, Rg[q:q + 1])["e_par"]))
    df = pd.DataFrame(rows); df.to_csv("outputs/field_diagnostics.csv", index=False)
    print(df.groupby("method")[[c for c in df.columns if c.startswith(("train_rel", "test_rel", "test_e", "mirror"))]].mean().to_string(float_format=lambda x: f"{x:.4f}"))
    if per:
        pe = pd.DataFrame(per); pe.to_csv("outputs/per_electron.csv", index=False)
        print(pe.groupby("electron")[["J_err", "e_par", "lon_gap_deg", "dL", "L", "alpha"]].mean().round(4).to_string())
        for c in ["e_par", "lon_gap_deg", "dL", "alpha"]:
            r = spearmanr(pe[c], pe["J_err"]); print(f"Spearman J_err vs {c}: rho={r.statistic:.2f} p={r.pvalue:.3g}")
