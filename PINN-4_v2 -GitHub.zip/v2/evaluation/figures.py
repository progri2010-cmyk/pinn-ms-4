"""evaluation/figures.py -- paper figures (PNG 200 dpi + PDF) into figures/."""
import numpy as np, pandas as pd, torch, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from evaluation.evaluate import load_field, evaluate_field, REFERENCE_FIELDS, rollout
from physics.invariants import mu, bounce_J, lshell_gc, guiding_centre
from training.segments import phase_space_curvature, uniform_nodes
from physics.fields import EPS

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6,
                     "axes.edgecolor": "#8a8984", "lines.linewidth": 1.6,
                     "savefig.bbox": "tight", "figure.dpi": 200})
C = {"uniform": "#2a78d6", "kappa05": "#eb6834", "kappa1": "#1baf7a", "error": "#eda100",
     "blackbox": "#6250d6", "single": "#e34948", "truth": "#0b0b0b", "dipole": "#8a8984"}
MK = {"uniform": "o", "kappa05": "s", "kappa1": "^", "error": "D"}
LAB = {"uniform": "MIC uniform", "kappa05": r"adaptive $\kappa^{1/2}$", "kappa1": r"adaptive $\kappa^{1}$",
       "error": "adaptive error"}
data = dict(np.load("data/dataset.npz")); dt = float(data["dt_obs"])


def smooth_err(x, w=650):
    k = np.ones(w) / w
    return np.convolve(np.pad(x, (w // 2, w - 1 - w // 2), mode="edge"), k, mode="valid")


def save(fig, name):
    fig.savefig(f"figures/{name}.png"); fig.savefig(f"figures/{name}.pdf"); plt.close(fig)


# ---- Fig 0: ground-truth orbit, three time scales ----
R = data["test_r"][0]
fig = plt.figure(figsize=(9, 3.2))
ax = fig.add_subplot(131, projection="3d")
ax.plot(*R.T, lw=0.4, color=C["uniform"]); ax.set_title("10 bounces (t = 140)")
ax.set_xlabel("x [R$_E$]"); ax.set_ylabel("y"); ax.set_zlabel("z")
ax2 = fig.add_subplot(132); n = 160
ax2.plot(R[:n, 0] - R[0, 0], R[:n, 2], color=C["uniform"], lw=0.8)
ax2.set_title("gyration + bounce (t < 3.2)"); ax2.set_xlabel(r"$\Delta x$ [R$_E$]"); ax2.set_ylabel("z [R$_E$]")
ax3 = fig.add_subplot(133); t = np.arange(len(R)) * dt
ax3.plot(t, np.degrees(np.unwrap(np.arctan2(R[:, 1], R[:, 0]) - np.arctan2(R[0, 1], R[0, 0]))), color=C["uniform"], lw=0.8)
ax3.set_title("azimuthal drift"); ax3.set_xlabel("t"); ax3.set_ylabel(r"$\Delta\varphi$ [deg]")
save(fig, "fig0_orbit")

# ---- Fig 1: curvature and node placement (K=24, training electron with alpha=40 deg) ----
p = 0
w = phase_space_curvature(data["train_r"][p], data["train_v"][p], dt, 6)
fig, ax = plt.subplots(figsize=(7, 2.6))
tt = (np.arange(len(w)) + 0.5) * dt
ax.plot(tt, w / w.mean(), color=C["truth"], lw=1.0, label=r"$\kappa(t)/\langle\kappa\rangle$")
for i, (key, y0) in enumerate([("uniform", 0.0), ("kappa05", -0.25)]):
    try:
        ck = torch.load(f"outputs/{key}_K24_s0.pt", weights_only=False); nd = np.array(ck["nodes"][p])
    except FileNotFoundError:
        continue
    ax.plot(nd * dt, np.full(len(nd), y0), MK[key], ms=4, color=C[key], label=f"{LAB[key]} nodes")
ax.set_xlabel("t  (R$_E$ / v)"); ax.set_ylabel("normalised curvature")
ax.legend(frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.22))
save(fig, "fig1_nodes")

# ---- Fig 2: invariant errors on an unseen electron (relative to ground truth) ----
models = {"dipole": REFERENCE_FIELDS["dipole_only"]}
for key, fn in [("uniform", "uniform_K48_s0"), ("kappa05", "kappa05_K48_s0")]:
    models[key] = load_field(f"outputs/{fn}.pt")[0]
Rg, Vg = data["test_r"], data["test_v"]; q = 1
t = np.arange(Rg.shape[1]) * dt
mg, Jg, Lg = mu(Rg[q:q+1], Vg[q:q+1], dt)[0], bounce_J(Rg[q], Vg[q], dt), lshell_gc(Rg[q:q+1], Vg[q:q+1])[0]
fig, axs = plt.subplots(1, 3, figsize=(10, 2.8))
for key, f in models.items():
    Rm, Vm = rollout(f, Rg[q:q + 1, 0], Vg[q:q + 1, 0], Rg.shape[1] - 1, 5)
    lab = "dipole only (no learning)" if key == "dipole" else LAB[key] + " (K=48)"
    axs[0].plot(t, smooth_err(np.abs(mu(Rm, Vm, dt)[0] - mg) / mg), color=C[key], lw=1.0, label=lab)
    J = bounce_J(Rm[0], Vm[0], dt); n = min(len(J), len(Jg))
    axs[1].plot(np.arange(1, n + 1), np.abs(J[:n] - Jg[:n]) / Jg[:n], marker=MK.get(key, "v"), ms=5, color=C[key])
    axs[2].plot(t, smooth_err(np.abs(lshell_gc(Rm, Vm)[0] - Lg)), color=C[key], lw=1.0)
for ax in axs: ax.set_yscale("log")
axs[0].set_title(r"$|\mu-\mu_{GT}|/\mu_{GT}$"); axs[0].set_xlabel("t  (training window = 14)")
axs[1].set_title(r"$|J-J_{GT}|/J_{GT}$ per bounce"); axs[1].set_xlabel("bounce #")
axs[2].set_title(r"$|L_{gc}-L_{gc,GT}|$  (proxy of $\Phi$)"); axs[2].set_xlabel("t")
for ax in (axs[0], axs[2]): ax.axvline(14, color=C["dipole"], ls=":", lw=1)
fig.legend(*axs[0].get_legend_handles_labels(), loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(0.5, 1.08))
save(fig, "fig2_invariants")

# ---- Fig 3: scaling with the segment budget K ----
df = pd.read_csv("outputs/results_all.csv")
fig, axs = plt.subplots(1, 3, figsize=(10, 2.8))
for key in ("uniform", "kappa05", "kappa1", "error"):
    sub = df[df.method.str.startswith(key + "_K")]
    if sub.empty: continue
    g = sub.groupby("K")
    for ax, met in zip(axs, ("final_data", "gc_rmse_10x", "J_err")):
        ax.errorbar(g[met].mean().index + {"uniform": -0.9, "kappa05": -0.3, "kappa1": 0.3, "error": 0.9}[key],
                    g[met].mean(), yerr=g[met].std(), marker=MK[key], ms=5, capsize=2, color=C[key], label=LAB[key])
ref = df.set_index("method")
for ax, met in zip(axs, ("final_data", "gc_rmse_10x", "J_err")):
    if met != "final_data":
        ax.axhline(ref.loc["dipole_only", met], color=C["dipole"], ls="--", lw=1)
        ax.axhline(ref.loc["true_field", met], color=C["truth"], ls=":", lw=1)
    ax.set_yscale("log"); ax.set_xlabel("segments per trajectory K"); ax.set_xticks([24, 32, 48])
axs[0].axhline(0.03, color=C["truth"], ls=":", lw=1)
axs[0].set_title("final training data loss"); axs[1].set_title("GC RMSE, 10x horizon [R$_E$]"); axs[2].set_title("relative J error")
fig.legend(*axs[1].get_legend_handles_labels(), loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.08))
save(fig, "fig3_scaling")

# ---- Fig 4: training curves ----
fig, axs = plt.subplots(1, 2, figsize=(8, 2.6), sharey=True)
for ax, K in zip(axs, (24, 48)):
    for key in ("uniform", "kappa05", "error"):
        for s in range(3):
            try:
                h = torch.load(f"outputs/{key}_K{K}_s{s}.pt", weights_only=False)["history"]
            except FileNotFoundError:
                continue
            ax.plot([e["data"] for e in h], color=C[key], lw=0.9, alpha=0.8, label=LAB[key] if s == 0 else None)
    ax.axhline(0.03, color=C["truth"], ls=":", lw=1); ax.set_yscale("log"); ax.set_title(f"K = {K}"); ax.set_xlabel("epoch")
axs[0].set_ylabel("data loss"); axs[0].legend(frameon=False)
save(fig, "fig4_training")
print("figures done")

# ---- Fig 5: phase-wrapping criterion -- collapse on N / N_c ----
import glob, re
from physics.fields import B_S
T_TRAIN = 14.0
pts = []
def add(path, storm, K, src):
    h = torch.load(path, weights_only=False)["history"]
    bs = storm * B_S; delta = bs / (1 - bs)
    N = (T_TRAIN / K) * (1 - bs) / (2 * np.pi * EPS)
    pts.append(dict(storm=storm, K=K, N=N, Nc=1 / (2 * delta), loss=h[-1]["data"], src=src))
for p in glob.glob("outputs/threshold/thr_storm*_K*_s*.pt"):
    m = re.search(r"storm([\d.]+)_K(\d+)", p); add(p, float(m.group(1)), int(m.group(2)), "threshold")
for p in glob.glob("outputs/uniform_K*_s*.pt"):
    add(p, 1.0, int(re.search(r"_K(\d+)", p).group(1)), "grid")
th = pd.DataFrame(pts); th.to_csv("outputs/threshold_points.csv", index=False)
fig, ax = plt.subplots(figsize=(5.2, 3.2))
for storm, col, mk in [(0.5, C["kappa1"], "^"), (1.0, C["uniform"], "o"), (2.0, C["kappa05"], "s")]:
    s = th[th.storm == storm]
    ax.plot(s.N / s.Nc, s.loss, mk, ms=6, color=col, ls="none",
            label=f"storm $b_s$ = {storm * B_S:.3f}  ($N_c$ = {s.Nc.iloc[0]:.1f})")
ax.axvline(1.0, color=C["truth"], lw=1, ls="--"); ax.axhline(0.03, color=C["dipole"], lw=1, ls=":")
ax.text(1.03, 0.12, r"$N = N_c$", fontsize=8); ax.text(0.56, 0.0255, "noise floor", fontsize=8, color="#52514e")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel(r"gyrations per segment / predicted limit   $N/N_c$,   $N_c = 1/(2\delta)$")
ax.set_ylabel("final training data loss"); ax.legend(frameon=False, fontsize=7.5, loc="center left", bbox_to_anchor=(0.0, 0.62))
save(fig, "fig5_phase_wrapping")
print("fig5 done")

# ---- Fig 6: segment curriculum (K 96 -> 48 -> 24) vs fixed K ----
fig, axs = plt.subplots(1, 3, figsize=(10.5, 2.8))
runs = [("uniform_K96", "uniform K = 96", C["kappa05"], "s"), ("uniform_K48", "uniform K = 48", C["uniform"], "o"),
        ("curriculum_K96to24", "curriculum 96 → 48 → 24", C["kappa1"], "^")]
for key, lab, col, mk in runs:
    h = torch.load(f"outputs/{key}_s0.pt", weights_only=False)["history"]
    axs[0].plot([e["data"] for e in h], color=col, lw=1.1, label=lab)
    if key.startswith("curriculum"):
        ks = [e.get("K_now", 96) for e in h]
        for j, ep in enumerate([i for i in range(1, len(ks)) if ks[i] != ks[i - 1]]):
            axs[0].axvline(ep, color=col, lw=0.8, ls=":")
            axs[0].text(ep + 3, [1.2, 0.55][j % 2], f"K→{ks[ep]}", fontsize=7, color="#52514e")
axs[0].axhline(0.0303, color=C["dipole"], ls="--", lw=0.8)
axs[0].set_yscale("log"); axs[0].set_xlabel("epoch"); axs[0].set_title("training data loss (seed 0)")
for ax, met, ttl in [(axs[1], "gc_rmse_10x", "GC RMSE, 10x horizon [R$_E$]"), (axs[2], "J_err", "relative J error")]:
    for i, (key, lab, col, mk) in enumerate(runs):
        v = df[df.method == key][met].values
        ax.plot(np.full(len(v), i) + np.linspace(-0.12, 0.12, len(v)), v, mk, ms=6, color=col, ls="none")
        ax.plot([i - 0.25, i + 0.25], [v.mean()] * 2, color="#0b0b0b", lw=1.5)
    ax.set_xticks(range(len(runs))); ax.set_xticklabels(["K=96", "K=48", "curric."]); ax.set_title(ttl)
axs[0].legend(frameon=False, fontsize=7.5)
save(fig, "fig6_curriculum")
print("fig6 done")

# ---- Fig 7: where generalisation is limited (capacity / noise / data / basis / integrator) ----
groups = [("true_field", "true field (reference)", C["truth"]),
          ("xp_harm_l2_K48", "harmonic l≤2 + exact-phase Boris", C["kappa1"]),
          ("xp_harm_l3_K48", "harmonic l≤3 + exact-phase Boris", C["kappa1"]),
          ("harm_l2_K48", "harmonic l≤2", C["kappa05"]),
          ("harm_l3_K48", "harmonic l≤3", C["kappa05"]),
          ("harm_l1_K48", "harmonic l≤1 (misspecified)", C["kappa05"]),
          ("uniform_K48", "MLP 64 (baseline)", C["uniform"]),
          ("cap_clean_K48", "MLP, noise-free data", C["uniform"]),
          ("cap_lam1_K48", "MLP, λ_reg = 1", C["uniform"]),
          ("data12_uniform_K48", "MLP, 12 trajectories", C["uniform"]),
          ("cap_ep600_K48", "MLP, 600 epochs", C["uniform"]),
          ("cap_h128_K48", "MLP 128", C["uniform"]),
          ("cap_h32_K48", "MLP 32", C["uniform"]),
          ("xp_mlp_K48", "MLP + exact-phase Boris", C["uniform"]),
          ("dipole_only", "dipole only (no learning)", C["dipole"])]
df = pd.read_csv("outputs/results_all.csv")
fig, axs = plt.subplots(1, 3, figsize=(11, 4.6), sharey=True)
for ax, met, ttl in zip(axs, ("gc_rmse_10x", "J_err", "drift_phase_err"),
                        ("GC RMSE, 10x horizon [R$_E$]", "relative J error", "drift-phase error [rad]")):
    for i, (key, lab, col) in enumerate(groups):
        v = df[df.method == key][met].values
        y = len(groups) - 1 - i
        ax.plot(v, np.full(len(v), y) + np.linspace(-0.15, 0.15, len(v)), "o", ms=4.5, color=col, alpha=0.85)
        ax.plot([v.mean()] * 2, [y - 0.32, y + 0.32], color="#0b0b0b", lw=1.4)
    ax.set_xscale("log"); ax.set_title(ttl); ax.grid(axis="y", visible=False)
axs[0].set_yticks(range(len(groups))); axs[0].set_yticklabels([g[1] for g in groups][::-1])
save(fig, "fig7_generalisation_limits")
print("fig7 done")

# ---- Fig 8: validation-based model selection on both truths ----
fam = lambda m: ("staged hybrid" if "shyb" in m else "hybrid" if "hyb" in m else
                 "harmonic" if "harm" in m else "MLP")
FC = {"MLP": (C["uniform"], "o"), "harmonic": (C["kappa05"], "s"), "hybrid": (C["blackbox"], "D"),
      "staged hybrid": (C["kappa1"], "^")}
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
for ax, tag, ttl in [(axs[0], "storm", "truth inside the l≤2 basis (storm)"),
                     (axs[1], "prc", "truth outside any harmonic basis (ring current)")]:
    try:
        d = pd.read_csv(f"outputs/results_{tag}.csv")
    except FileNotFoundError:
        continue
    tr = d[d.val_loss.notna()]
    for f_, (col, mk) in FC.items():
        s = tr[tr.method.map(fam) == f_]
        ax.plot(s.val_loss, s.J_err, mk, ms=6, color=col, ls="none", label=f_, alpha=0.9)
    ref = d.set_index("method")
    ax.axhline(ref.loc["dipole_only", "J_err"], color=C["dipole"], ls="--", lw=1)
    ax.text(tr.val_loss.min(), ref.loc["dipole_only", "J_err"] * 0.88, "dipole only", fontsize=7, color="#52514e", va="top")
    best = tr.loc[tr.val_loss.idxmin()]
    ax.plot(best.val_loss, best.J_err, "o", ms=13, mfc="none", mec="#0b0b0b", mew=1.3)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_title(ttl)
    ax.set_xlabel("validation shooting loss (held-out electrons, no true field)")
axs[0].set_ylabel("relative J error, 10x test"); axs[0].legend(frameon=False, fontsize=7.5, loc="lower right")
save(fig, "fig8_validation_selection")
print("fig8 done")

# ---- Fig 9: one procedure on both truths (validation-selected configurations) ----
SEL = {"storm": [("dipole_only", "dipole only", C["dipole"]), ("xp_mlp_K48", "MLP", C["uniform"]),
                 ("xp_harm_l2_K48", "harmonic (val-selected l=2)", C["kappa05"]),
                 ("xp_hyb_l2_K48", "hybrid, simultaneous", C["blackbox"]),
                 ("xp_shyb_l2_lam10_K48", "staged hybrid (val-selected l, λ)", C["kappa1"])],
       "prc": [("dipole_only", "dipole only", C["dipole"]), ("prc_mlp_K64", "MLP", C["uniform"]),
               ("prc_harm_l3_K64", "harmonic (val-selected l=3)", C["kappa05"]),
               ("prc_hyb_l2_K64", "hybrid, simultaneous", C["blackbox"]),
               ("prc_shyb_l2_lam01_K64", "staged hybrid (val-selected l, λ)", C["kappa1"])]}
from matplotlib.ticker import NullFormatter
fig, axs = plt.subplots(2, 2, figsize=(10, 5.8), sharey="row", gridspec_kw={"hspace": 0.55})
for r_, (tag, ttl) in enumerate([("storm", "truth inside basis (storm)"), ("prc", "truth outside basis (ring current)")]):
    d = pd.read_csv(f"outputs/results_{tag}.csv")
    for c_, (met, mt) in enumerate([("J_err", "relative J error"), ("gc_rmse_10x", "GC RMSE 10x [R$_E$]")]):
        ax = axs[r_, c_]
        for i, (key, lab, col) in enumerate(SEL[tag]):
            v = d[d.method == key][met].values; y = len(SEL[tag]) - 1 - i
            ax.plot(v, np.full(len(v), y) + np.linspace(-0.15, 0.15, len(v)), "o", ms=5, color=col)
            ax.plot([v.mean()] * 2, [y - 0.32, y + 0.32], color="#0b0b0b", lw=1.4)
        ax.set_xscale("log"); ax.grid(axis="y", visible=False)
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.set_title(f"{ttl}: {mt}", fontsize=8.5)
        ax.set_yticks(range(len(SEL[tag]))); ax.set_yticklabels([s[1] for s in SEL[tag]][::-1])
from matplotlib.ticker import FixedLocator, FuncFormatter
for ax, ticks in [(axs[1, 1], [0.4, 0.5, 0.6, 0.8, 1.0]), (axs[1, 0], [0.03, 0.05, 0.1, 0.2, 0.5])]:
    ax.xaxis.set_major_locator(FixedLocator(ticks))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}"))
save(fig, "fig9_one_procedure")
print("fig9 done")

# ---- Fig 10: out-of-basis head-to-head with 10 seeds, and best-of-k selection by validation ----
import itertools
d = pd.read_csv("outputs/results_prc.csv")
H = d[d.method == "prc_shyb_l2_lam01_K64"]; M = d[d.method == "prc_mlp_K64"]
fig, axs = plt.subplots(1, 3, figsize=(11, 3.2))
for df_, lab, col, mk in [(H, "staged hybrid (l≤2, λ=0.1)", C["kappa1"], "^"), (M, "MLP", C["uniform"], "o")]:
    axs[0].plot(df_.val_loss, df_.J_err, mk, ms=6, color=col, ls="none", label=lab)
axs[0].set_xlabel("validation shooting loss"); axs[0].set_ylabel("relative J error, 10x test")
axs[0].set_title(f"{len(H)} seeds each (ring-current truth)"); axs[0].legend(frameon=False, fontsize=7.5, loc="upper left")
for ax, met, ttl in [(axs[1], "J_err", "relative J error"), (axs[2], "drift_phase_err", "drift-phase error [rad]")]:
    for df_, lab, col, mk, dx in [(H, "staged hybrid", C["kappa1"], "^", -0.08), (M, "MLP", C["uniform"], "o", 0.08)]:
        mean, p10, p90 = [], [], []
        vl, mv = df_.val_loss.values, df_[met].values
        for k in (1, 2, 3, 4, 5):
            v = [mv[list(c)][np.argmin(vl[list(c)])] for c in itertools.combinations(range(len(df_)), k)]
            mean.append(np.mean(v)); p10.append(np.percentile(v, 10)); p90.append(np.percentile(v, 90))
        ks = np.arange(1, 6) + dx
        ax.errorbar(ks, mean, yerr=[np.subtract(mean, p10), np.subtract(p90, mean)], marker=mk, ms=5,
                    capsize=2, color=col, label=lab)
    ax.set_xlabel("seeds trained, best kept by validation (k)"); ax.set_title(f"{ttl}: mean, 10–90%")
    ax.set_xticks(range(1, 6))
save(fig, "fig10_best_of_k")
print("fig10 done")

# ---- Fig 11: J-error vs drift-phase trade-off out of basis (mean ± sd over seeds) ----
d = pd.read_csv("outputs/results_prc.csv")
pts11 = [("prc_mlp_K64", "MLP", C["uniform"], "o"),
         ("prc_hyb_l2_K64", "hybrid, simultaneous (stage 1 = 0)", C["blackbox"], "D"),
         ("prc_shyb_l2_st25_K64", "staged, stage 1 = 25", C["kappa1"], "v"),
         ("prc_shyb_l2_st50_K64", "staged, stage 1 = 50", C["kappa1"], "^"),
         ("prc_shyb_l2_lam01_K64", "staged, stage 1 = 100", C["kappa1"], "s"),
         ("prc_shyb_l1_K64", "staged, l = 1 basis", C["kappa05"], "<"),
         ("prc_shyb_l2b1_K64", "staged, l = 2 penalised (λ_b = 1)", C["kappa05"], ">")]
fig, ax = plt.subplots(figsize=(8.8, 3.8))
for key, lab, col, mk in pts11:
    x = d[d.method == key]
    ax.errorbar(x.drift_phase_err.mean(), x.J_err.mean(), xerr=x.drift_phase_err.std(), yerr=x.J_err.std(),
                marker=mk, ms=7, capsize=2, color=col, ls="none", label=f"{lab} (n={len(x)})")
ax.set_yscale("log"); ax.set_xlabel("drift-phase error [rad]  (Φ axis)"); ax.set_ylabel("relative J error")
ax.set_title("ring-current truth: no configuration wins both axes")
ax.legend(frameon=False, fontsize=7.5, loc="center left", bbox_to_anchor=(1.01, 0.5))
save(fig, "fig11_tradeoff")
print("fig11 done")

# ---- Fig 12: stage-1 control (equal stage 2 with optimiser restart vs original schedule) ----
d = pd.read_csv("outputs/results_prc.csv")
fig, axs = plt.subplots(1, 2, figsize=(10, 3.4))
series = {"restart (stage 2 = 300 epochs, fresh optimiser)": (["prc_hyb_l2_K64", "prc_shyb_l2_st25r_K64", "prc_shyb_l2_st50r_K64", "prc_shyb_l2_st100r_K64"], C["kappa1"], "o", -1.5),
          "original (300 epochs in total)": (["prc_hyb_l2_K64", "prc_shyb_l2_st25_K64", "prc_shyb_l2_st50_K64", "prc_shyb_l2_lam01_K64"], C["kappa05"], "s", 1.5)}
for lab, (keys, col, mk, dx) in series.items():
    for ax, met in zip(axs, ("drift_phase_err", "J_err")):
        m_ = [d[d.method == k][met].mean() for k in keys]; s_ = [d[d.method == k][met].std() for k in keys]
        ax.errorbar(np.array([0, 25, 50, 100]) + dx, m_, yerr=s_, marker=mk, ms=6, capsize=2, color=col, label=lab)
for ax, met, ttl in zip(axs, ("drift_phase_err", "J_err"), ("drift-phase error [rad]", "relative J error")):
    for key, lab, ls in [("prc_mlp_K64", "MLP 300 epochs", "--"), ("prc_mlp_ep200_K64", "MLP 200 epochs", ":")]:
        ax.axhline(d[d.method == key][met].mean(), color=C["uniform"], ls=ls, lw=1.2, label=lab)
    ax.set_xlabel("stage 1 (basis only) [epochs]"); ax.set_title(f"ring-current truth: {ttl}"); ax.set_xticks([0, 25, 50, 100])
axs[1].set_yscale("log")
h_, l_ = axs[0].get_legend_handles_labels()
fig.legend(h_, l_, frameon=False, fontsize=7.5, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.04))
save(fig, "fig12_stage1_control")

# ---- Fig 13: parameter-free phase criterion, both integrators ----
pc = pd.read_csv("outputs/phase_criterion.csv")
fig, ax = plt.subplots(figsize=(6.4, 3.6))
for (integ, storm), sub in pc.groupby(["integrator", "storm"]):
    col = {0.5: C["kappa1"], 1.0: C["uniform"], 2.0: C["kappa05"]}[storm]
    mk = "o" if integ == "standard" else "^"
    jitter = 1 + 0.02 * (np.arange(len(sub)) % 3 - 1)
    ax.plot(sub.dphi_median * jitter, sub.loss, mk, ms=5.5, color=col, ls="none", alpha=0.85,
            mfc=col if integ == "standard" else "none", label=f"{integ} Boris, storm ×{storm:g}")
ax.axvline(2.83, color=C["truth"], ls="--", lw=1); ax.text(2.88, 0.15, "2.83 rad", fontsize=7.5)
ax.axvline(np.pi, color=C["dipole"], ls=":", lw=1); ax.text(3.2, 0.075, "π", fontsize=8, color="#52514e")
ax.set_xscale("log"); ax.set_yscale("log")
from matplotlib.ticker import FixedLocator as _FL, FuncFormatter as _FF, NullFormatter as _NF
ax.xaxis.set_major_locator(_FL([1, 1.5, 2, 3, 4, 6])); ax.xaxis.set_major_formatter(_FF(lambda x, _: f"{x:g}"))
ax.xaxis.set_minor_formatter(_NF())
ax.set_xlabel(r"median initial phase mismatch per segment  $\Delta\varphi_0$ [rad]"); ax.set_ylabel("final training data loss")
ax.legend(frameon=False, fontsize=6.5, ncol=1, loc="lower right")
save(fig, "fig13_phase_criterion")
print("fig12-13 done")
