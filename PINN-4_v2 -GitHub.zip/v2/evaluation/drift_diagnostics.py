"""
evaluation/drift_diagnostics.py -- why does a model drift wrongly?
Magnetic drift = gradient drift (b x grad|B|) + curvature drift (b x kappa_b),
kappa_b = (b . grad) b. On test-trajectory points we compare the model's
grad_perp|B| and kappa_b with the true field's, and correlate the errors with
the drift-phase error of each checkpoint.
Usage: RB_TRUTH=prc python -m evaluation.drift_diagnostics data/dataset_prc.npz methodA methodB
"""
import sys, glob, os
import numpy as np, pandas as pd, torch
from scipy.stats import spearmanr, mannwhitneyu
torch.set_num_threads(1)
from physics.fields import true_field_torch, TRUTH
from evaluation.evaluate import load_field

data = dict(np.load(sys.argv[1])); methods = sys.argv[2:]
pts = torch.tensor(data["test_r"][:, ::20].reshape(-1, 3))


def drift_terms(field, r):
    r = r.clone().requires_grad_(True)
    B = field(r); Bm = B.norm(dim=-1, keepdim=True); b = B / Bm
    gB = torch.autograd.grad(Bm.sum(), r, retain_graph=True)[0]
    gperp = gB - (gB * b).sum(-1, keepdim=True) * b
    Jb = torch.stack([torch.autograd.grad(b[:, i].sum(), r, retain_graph=True)[0] for i in range(3)], 1)
    kappa = torch.einsum("nij,nj->ni", Jb, b)
    return gperp.detach(), kappa.detach(), b.detach()


gT, kT, bT = drift_terms(true_field_torch, pts)
res = pd.read_csv(f"outputs/results_{TRUTH}.csv")
rows = []
for m in methods:
    for p in sorted(glob.glob(f"outputs/{m}_s*.pt")):
        seed = int(os.path.basename(p)[:-3].rsplit("_s", 1)[1])
        f, _ = load_field(p)
        g, k, _ = drift_terms(f, pts)
        dp = res[(res.method == m) & (res.seed == seed)]["drift_phase_err"]
        rows.append(dict(method=m, seed=seed,
                         gperp_err=((g - gT).norm(dim=-1) / gT.norm(dim=-1)).median().item(),
                         kappa_err=((k - kT).norm(dim=-1) / kT.norm(dim=-1)).median().item(),
                         drift_phase_err=dp.iloc[0] if len(dp) else np.nan))
df = pd.DataFrame(rows); df.to_csv(f"outputs/drift_diagnostics_{TRUTH}.csv", index=False)
print(df.groupby("method")[["gperp_err", "kappa_err", "drift_phase_err"]].agg(["mean", "std"]).to_string(float_format=lambda x: f"{x:.4f}"))
for c in ["gperp_err", "kappa_err"]:
    a, b_ = (df[df.method == m][c] for m in methods[:2])
    d = df.dropna(); r = spearmanr(d[c], d.drift_phase_err)
    print(f"{c}: {methods[0]} vs {methods[1]} MWU p={mannwhitneyu(a, b_).pvalue:.3g};  Spearman with drift-phase error rho={r.statistic:.2f} p={r.pvalue:.2g} n={len(d)}")
