"""
evaluation/aggregate.py -- evaluate every checkpoint on the 10x test, write
outputs/results_all.csv (one row per run) and outputs/table_main.csv (mean +/- std),
plus paired seed-wise comparisons adaptive vs uniform (Wilcoxon signed-rank).
"""
import glob, os, re, json
import numpy as np, pandas as pd, torch
from scipy.stats import wilcoxon
torch.set_num_threads(2)
from evaluation.evaluate import load_field, evaluate_field, REFERENCE_FIELDS

data = dict(np.load("data/dataset.npz"))
rows = []
for name, f in REFERENCE_FIELDS.items():
    m, _ = evaluate_field(f, data); m.update(method=name, K=np.nan, seed=0, final_data=np.nan,
                                             train_time=0.0); rows.append(m)
for p in sorted(glob.glob("outputs/*_s*.pt")):
    base = os.path.basename(p)[:-3]
    if base.startswith("prc_"):          # out-of-basis truth: evaluated by evaluation/eval_truth.py
        continue
    method, seed = base.rsplit("_s", 1)
    field, ck = load_field(p)
    cache = f"outputs/metrics/{base}.json"
    if os.path.exists(cache):
        m = json.load(open(cache))
    else:
        m, _ = evaluate_field(field, data)
        m = {k: float(v) for k, v in m.items()}
        os.makedirs("outputs/metrics", exist_ok=True); json.dump(m, open(cache, "w"))
    h = ck["history"]
    Km = re.search(r"_K(\d+)", method)
    m.update(method=method, K=int(Km.group(1)) if Km else 1, seed=int(seed),
             final_data=h[-1]["data"], train_time=h[-1]["time"])
    rows.append(m); print(base, f"gc10x={m['gc_rmse_10x']:.3e} J={m['J_err']:.3e}", flush=True)
df = pd.DataFrame(rows)
df.to_csv("outputs/results_all.csv", index=False)

cols = ["final_data", "pos_rmse_1x", "gc_rmse_1x", "gc_rmse_10x", "mu_err", "J_err", "L_err",
        "drift_phase_err", "energy_drift", "train_time"]
g = df.groupby("method")[cols]
tab = g.mean().add_suffix("_mean").join(g.std().add_suffix("_std")).join(g.size().rename("n"))
tab.to_csv("outputs/table_main.csv")

lines = []
for K in (24, 32, 48):
    u = df[df.method == f"uniform_K{K}"].sort_values("seed")
    for a in ("kappa05", "kappa1", "error"):
        x = df[df.method == f"{a}_K{K}"].sort_values("seed")
        n = min(len(u), len(x))
        for met in ("gc_rmse_10x", "J_err"):
            du = u[met].values[:n]; dx = x[met].values[:n]
            wins = int(np.sum(dx < du))
            p = wilcoxon(dx, du).pvalue if n >= 3 and np.any(dx != du) else np.nan
            lines.append(dict(K=K, method=a, metric=met, n=n, uniform_mean=du.mean(),
                              adaptive_mean=dx.mean(), rel_change=(dx.mean() - du.mean()) / du.mean(),
                              wins=wins, wilcoxon_p=p))
pd.DataFrame(lines).to_csv("outputs/paired_tests.csv", index=False)
print("done")
