"""
evaluation/head_to_head.py -- statistics for model A vs model B over seeds.
Mann-Whitney U (two-sided), bootstrap 95% CI of the ratio of means A/B (10 000
resamples, seeds resampled independently within each model), Cliff's delta
(-1 = A always lower/better, +1 = A always higher).
Usage: python -m evaluation.head_to_head outputs/results_prc.csv methodA methodB
"""
import sys
import numpy as np, pandas as pd
from scipy.stats import mannwhitneyu

path, A, B = sys.argv[1:4]
df = pd.read_csv(path); rng = np.random.default_rng(0)
rows = []
for m in ["J_err", "gc_rmse_10x", "mu_err", "L_err", "drift_phase_err", "mirror_profile_err", "val_loss"]:
    a = df[df.method == A][m].dropna().values; b = df[df.method == B][m].dropna().values
    boots = [rng.choice(a, len(a)).mean() / rng.choice(b, len(b)).mean() for _ in range(10000)]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    cliff = (np.sum(a[:, None] > b[None, :]) - np.sum(a[:, None] < b[None, :])) / (len(a) * len(b))
    rows.append(dict(metric=m, nA=len(a), nB=len(b), meanA=a.mean(), sdA=a.std(ddof=1), meanB=b.mean(),
                     sdB=b.std(ddof=1), ratio=a.mean() / b.mean(), ci_lo=lo, ci_hi=hi,
                     cliffs_delta=cliff, mwu_p=mannwhitneyu(a, b).pvalue))
out = pd.DataFrame(rows)
out.to_csv(f"outputs/head_to_head_{A}_vs_{B}.csv", index=False)
print(out.to_string(index=False, float_format=lambda x: f"{x:.4g}"))
