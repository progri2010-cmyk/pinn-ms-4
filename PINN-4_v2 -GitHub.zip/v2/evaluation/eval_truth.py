"""
evaluation/eval_truth.py -- evaluate a family of checkpoints against the truth
selected by RB_TRUTH, on a given dataset, with model selection by validation loss.
Usage: RB_TRUTH=prc python -m evaluation.eval_truth data/dataset_prc.npz prefix1 prefix2 ...
Writes outputs/results_<tag>.csv and outputs/table_<tag>.csv
Oracle references: harmonic basis with least-squares coefficients fitted to the
TRUE field on the electron shell -- the best any training could do in that basis.
"""
import sys, os, glob, json
import numpy as np, pandas as pd, torch
torch.set_num_threads(2)
from physics.fields import TRUTH, true_field_torch, dipole_torch
from evaluation.evaluate import load_field, evaluate_field, REFERENCE_FIELDS
from evaluation.field_diagnostics import components, mirror_profile_err
from evaluation.validate import validation_loss
from models.harmonic_field import HarmonicField

dpath, prefixes = sys.argv[1], sys.argv[2:]
data = dict(np.load(dpath)); tag = TRUTH
os.makedirs(f"outputs/metrics_{tag}", exist_ok=True)


def oracle(l):
    rng = np.random.default_rng(0); n = 3000
    rr = rng.uniform(3.6, 4.4, n); la = np.radians(rng.uniform(-35, 35, n)); ph = rng.uniform(0, 2 * np.pi, n)
    pts = torch.tensor(np.stack([rr * np.cos(la) * np.cos(ph), rr * np.cos(la) * np.sin(ph), rr * np.sin(la)], -1))
    target = (true_field_torch(pts) - dipole_torch(pts)).reshape(-1)
    h = HarmonicField(l); cols = []
    for k in range(h.coef.numel()):
        h.coef.data.zero_(); h.coef.data[k] = 1; cols.append(h.residual(pts).reshape(-1))
    c = torch.linalg.lstsq(torch.stack(cols, 1), target.unsqueeze(1)).solution.squeeze()
    h.coef.data = c; h.exact_phase = True
    return h


rows = []
refs = dict(REFERENCE_FIELDS); refs.update({f"oracle_harm_l{l}": oracle(l) for l in (2, 3)})
for name, f in refs.items():
    cache = f"outputs/metrics_{tag}/ref_{name}.json"
    if os.path.exists(cache):
        m = json.load(open(cache))
    else:
        m, _ = evaluate_field(f, data)
        m = {k: float(v) for k, v in m.items()}
        m["mirror_profile_err"] = mirror_profile_err(f, data)
        json.dump(m, open(cache, "w"))
    m.update(method=name, seed=0, val_loss=np.nan)
    rows.append(m)
for pre in prefixes:
    for p in sorted(glob.glob(f"outputs/{pre}_s*.pt")):
        base = os.path.basename(p)[:-3]; cache = f"outputs/metrics_{tag}/{base}.json"
        if os.path.exists(cache):
            m = json.load(open(cache))
        else:
            try:
                f, ck = load_field(p)
            except Exception as e:                       # checkpoint still being written
                print("skip (not readable yet)", base, e); continue
            m, _ = evaluate_field(f, data)
            m = {k: float(v) for k, v in m.items()}
            if not getattr(f, "is_node", False):          # a Neural ODE has no magnetic field to inspect
                m["mirror_profile_err"] = mirror_profile_err(f, data)
                m.update({f"test_{k}": v for k, v in components(f, data["test_r"]).items()})
            m["val_loss"] = validation_loss(p, data) if "val_r" in data else float("nan")
            m["final_data"] = ck["history"][-1]["data"]; m["train_time"] = ck["history"][-1]["time"]
            json.dump(m, open(cache, "w"))
        m.update(method=base.rsplit("_s", 1)[0], seed=int(base.rsplit("_s", 1)[1]))
        rows.append(m); print(base, f"gc10x={m['gc_rmse_10x']:.3e} J={m['J_err']:.3e} val={m.get('val_loss', np.nan):.4f}", flush=True)
df = pd.DataFrame(rows); df.to_csv(f"outputs/results_{tag}.csv", index=False)
num = df.select_dtypes("number").columns.drop("seed")
g = df.groupby("method")[list(num)]
g.mean().add_suffix("_mean").join(g.std().add_suffix("_std")).join(g.size().rename("n")).to_csv(f"outputs/table_{tag}.csv")
print("done")
