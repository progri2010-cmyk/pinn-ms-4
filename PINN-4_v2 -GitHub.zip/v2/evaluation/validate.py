"""
evaluation/validate.py -- model selection WITHOUT the true field.
Validation shooting loss: on 4 held-out noisy electrons (never used in training),
segments start at the noisy observations (nodes are not optimised) and the model
predicts each segment forward; the score is the same scaled data loss as in training.
Lower is better. Uses the same segment count K and integrator as the checkpoint.
"""
import numpy as np, torch
from training.mic import Trainer, default_cfg
from evaluation.evaluate import load_field


@torch.no_grad()
def validation_loss(ckpt_path, data):
    field, ck = load_field(ckpt_path)
    cfg = default_cfg(**{**ck["cfg"], "schedule": "uniform", "K": ck["cfg"].get("K", 48), "verbose": False})
    vd = {"obs_r": data["val_r"], "obs_v": data["val_v"], "dt_obs": data["dt_obs"]}
    tr = Trainer(vd, cfg)
    tr.model = field
    _, info, _, _ = tr.loss()
    return info["data"]
