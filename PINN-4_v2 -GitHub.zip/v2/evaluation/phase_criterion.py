"""
evaluation/phase_criterion.py -- parameter-free version of the phase-wrapping criterion.
For each uniform segment of each (noise-free) training trajectory, the gyro-phase
mismatch that the INITIAL model (dipole only) accumulates is
    dphi = (1/eps) * integral (|B_true| - |B_dipole|) dt     over the segment.
MIC is predicted to stall when this exceeds ~pi. Compared with the training outcome
of every threshold run (final data loss < 0.06 = converged).
"""
import glob, re
import numpy as np, pandas as pd, torch
from physics.fields import dipole_np, storm_np, B_S, B_A, EPS


def dphi_stats(R, K, storm, dt=0.02):
    B_true = np.linalg.norm(dipole_np(R) + storm_np(R, storm * B_S, storm * B_A), axis=-1)
    B_dip = np.linalg.norm(dipole_np(R), axis=-1)
    rate = (B_true - B_dip) / EPS                          # (P, T) phase-mismatch rate
    N = R.shape[1] - 1
    nodes = np.unique(np.round(np.linspace(0, N, K + 1)).astype(int))
    seg = [np.abs(np.trapezoid(rate[:, a:b + 1], dx=dt, axis=1)) for a, b in zip(nodes[:-1], nodes[1:])]
    seg = np.concatenate(seg)
    return np.median(seg), np.percentile(seg, 90), seg.max()


rows = []
for pattern, integ in [("outputs/threshold/thr_storm*_K*_s*.pt", "standard"),
                       ("outputs/uniform_K*_s*.pt", "standard"),
                       ("outputs/threshold_xp/xpthr_storm*_K*_s*.pt", "exact-phase")]:
    for p in glob.glob(pattern):
        m = re.search(r"storm([\d.]+)_K(\d+)", p)
        storm, K = (float(m.group(1)), int(m.group(2))) if m else (1.0, int(re.search(r"_K(\d+)", p).group(1)))
        h = torch.load(p, weights_only=False)["history"]
        rows.append(dict(storm=storm, K=K, integrator=integ, loss=h[-1]["data"], path=p))
df = pd.DataFrame(rows)
cache = {}
for storm in df.storm.unique():
    f = "data/dataset.npz" if storm == 1.0 else f"data/dataset_storm{storm:g}.npz"
    cache[storm] = np.load(f)["train_r"]
st = {(s, K): dphi_stats(cache[s], K, s) for s, K in set(zip(df.storm, df.K))}
df["dphi_median"] = [st[(s, K)][0] for s, K in zip(df.storm, df.K)]
df["dphi_p90"] = [st[(s, K)][1] for s, K in zip(df.storm, df.K)]
df["dphi_max"] = [st[(s, K)][2] for s, K in zip(df.storm, df.K)]
df["converged"] = df.loss < 0.06
df.drop(columns="path").to_csv("outputs/phase_criterion.csv", index=False)
g = df.groupby(["integrator", "storm", "K"]).agg(dphi_median=("dphi_median", "first"), dphi_p90=("dphi_p90", "first"),
                                                 n=("loss", "size"), conv=("converged", "sum"), loss=("loss", "mean")).reset_index()
print(g.round(3).to_string(index=False))
for col in ("dphi_median", "dphi_p90"):
    best = max(((np.mean((df[col] < t) == df.converged), t) for t in np.linspace(1, 6, 501)))
    print(f"{col}: best single threshold {best[1]:.2f} rad classifies {100 * best[0]:.1f}% of {len(df)} runs (pi = 3.14)")
