"""Third round: capacity / regularisation / noise (uniform K=48, 3 seeds)."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
jobs = []
cfgs = {"cap_lam0": "lam_reg=0.0", "cap_lam1e-4": "lam_reg=0.0001", "cap_lam1e-2": "lam_reg=0.01", "cap_lam1e-1": "lam_reg=0.1", "cap_lam1": "lam_reg=1.0",
        "cap_h32": "hidden=32", "cap_h128": "hidden=128", "cap_ep600": "epochs=600",
        "cap_clean": "data=data/dataset_noise0.npz"}
for s in range(3):
    for name, extra in cfgs.items():
        ep = "" if "epochs" in extra else "epochs=300"
        jobs.append((f"{name}_K48", s, f"K=48 {ep} {extra}"))
jobs.sort(key=lambda j: ("h128" in j[0] or "ep600" in j[0]))
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f, stderr=subprocess.STDOUT)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID3 DONE")
