"""Fourth round: physics-structured residual (external vacuum harmonics), K=48, 3 seeds."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
jobs = [(f"harm_l{l}_K48", s, f"K=48 epochs=300 model=harmonic l_max={l} lr=0.01 lam_reg=0.0")
        for s in range(3) for l in (1, 2, 3)]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f, stderr=subprocess.STDOUT)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID4 DONE")
