"""
training/segments.py -- placement of shooting nodes on the observation grid.

All schedulers return, per trajectory, sorted node indices n_0=0 < n_1 < ... < n_{K-1}
on the observation grid; segment k covers [n_k, n_{k+1}] (last one ends at N).

uniform            : equal-length segments.
density(w)         : equidistribution -- the cumulative density int w dt is split
                     into K equal parts, so each segment carries the same "difficulty".
phase-space curvature kappa(t) = ||d^2 z/dt^2||, z = (r/eps, v), smoothed over one
gyro-period (otherwise it oscillates with gyrophase). For Lorentz motion
kappa ~ Omega^2 v_perp, so rho ~ kappa^(1/2) ~ Omega equalises the number of
gyro-rotations per segment (the local Lyapunov-type growth rate), and
rho ~ kappa^1 over-weights the mirror points.
"""
import numpy as np
from physics.invariants import smooth
from physics.fields import EPS


def uniform_nodes(N, K):
    return np.unique(np.round(np.linspace(0, N, K + 1)[:-1]).astype(int))


def density_nodes(w, K, min_len=3):
    """w: (N,) positive weight per observation interval."""
    N = len(w)
    c = np.concatenate([[0.0], np.cumsum(w)])
    targets = np.linspace(0, c[-1], K + 1)[:-1]
    nodes = np.searchsorted(c, targets, side="right") - 1
    nodes = np.clip(nodes, 0, N - min_len)
    out = [0]
    for n in nodes[1:]:                 # enforce minimum length, keep K nodes if possible
        out.append(max(n, out[-1] + min_len))
    out = np.array(out)
    out = out[out <= N - min_len]
    return out


def phase_space_curvature(r, v, dt, smooth_obs):
    """r, v: (T, 3) -> kappa per interval (T-1,)."""
    z = np.concatenate([r / EPS, v], -1)
    d2 = np.zeros_like(z)
    d2[1:-1] = (z[2:] - 2 * z[1:-1] + z[:-2]) / dt ** 2
    d2[0], d2[-1] = d2[1], d2[-2]
    k = np.linalg.norm(d2, axis=-1)
    k = smooth(k, smooth_obs)
    return 0.5 * (k[1:] + k[:-1])


def segments_from_nodes(nodes, N):
    starts = np.asarray(nodes)
    ends = np.append(starts[1:], N)
    return starts, ends - starts
