"""
training/mic.py -- Multiple-shooting (MIC) training of the hybrid field model
through a differentiable Boris integrator.

Unknowns: network weights theta AND the state z_k=(r,v) at every shooting node
(Yang et al.-style multiple shooting). Loss:
  L = L_data + lam_node * L_node + lam_cont * L_cont + lam_reg * L_reg
  L_data : predicted vs observed states inside each segment
  L_node : node states vs observations at the node
  L_cont : end of segment k vs node k+1 (shooting defect)
  L_reg  : mean |curl A|^2 on collocation points (smallest deviation from known physics)
Positions are scaled by eps (gyroradius) and velocities by |v| = 1, so a gyrophase
error costs the same in both.

schedule: 'single' | 'uniform' | 'kappa' (beta) | 'error' | 'curriculum'
Adaptive schedules are refreshed every `refresh` epochs from the current model's
predicted trajectory, with damping eta (w <- (1-eta) w_old + eta w_new).

'curriculum' follows from the phase-wrapping bound N < N_c = 1/(2 delta): training
starts with many short segments (K large) while the field error delta is large;
once the data loss reaches merge_tol (delta has shrunk, N_c has grown) every second
node is removed, doubling segment length, until K_min. Merged segments start from
the model's own predicted states, so no information is thrown away.
"""
import time
import numpy as np
import torch
from physics.fields import EPS
from physics.boris import boris_torch
from physics.invariants import smooth
from models.field_net import CurlField
from models.harmonic_field import HarmonicField
from models.hybrid_field import HybridField
from models.node import SecondOrderNODE, rk4_step
from training.segments import (uniform_nodes, density_nodes, phase_space_curvature,
                               segments_from_nodes)

DT_MODEL = 0.004


def default_cfg(**kw):
    c = dict(schedule="uniform", K=24, beta=0.5, prior="dipole", epochs=500, lr=3e-3,
             lr_nodes=3e-3, lam_node=1.0, lam_cont=1.0, lam_reg=1e-3, refresh=50,
             warmup=100, eta=0.5, hidden=64, depth=3, seed=0, min_len=3,
             out_scale=None, verbose=True, model="mlp", l_max=3, exact_phase=False, stage1=0, lam_basis2=0.0, restart_stage2=False, K_min=24, merge_tol=0.05, merge_gap=40)
    c.update(kw)
    if c["out_scale"] is None:
        c["out_scale"] = 0.1 if c["prior"] == "dipole" else 1.0
    return c


def build_model(cfg):
    if cfg.get("model", "mlp") == "harmonic":
        return HarmonicField(cfg["l_max"])
    if cfg.get("model", "mlp") == "node":
        return SecondOrderNODE(cfg["hidden"], cfg["depth"])
    if cfg.get("model", "mlp") == "hybrid":
        return HybridField(cfg["l_max"], cfg["hidden"], cfg["depth"], cfg["out_scale"])
    return CurlField(cfg["hidden"], cfg["depth"], cfg["prior"], cfg["out_scale"])


class Trainer:
    def __init__(self, data, cfg):
        self.cfg = cfg
        torch.manual_seed(cfg["seed"]); np.random.seed(cfg["seed"])
        self.dt_obs = float(data["dt_obs"])
        self.sub = int(round(self.dt_obs / DT_MODEL))
        self.obs = np.concatenate([data["obs_r"], data["obs_v"]], -1)    # (P, T, 6)
        self.P, T, _ = self.obs.shape
        self.N = T - 1
        self.obs_t = torch.tensor(self.obs)
        self.model = build_model(cfg)
        self.scale = torch.tensor([1 / EPS] * 3 + [1.0] * 3, dtype=torch.float64)
        self.gyro_obs = max(1, int(round(2 * np.pi * EPS / self.dt_obs)))
        g = torch.Generator().manual_seed(1234)          # collocation shell 3.4-4.6 R_E, |lat|<35deg
        rr = 3.4 + 1.2 * torch.rand(2048, generator=g, dtype=torch.float64)
        ph = 2 * np.pi * torch.rand(2048, generator=g, dtype=torch.float64)
        la = np.radians(35) * (2 * torch.rand(2048, generator=g, dtype=torch.float64) - 1)
        self.colloc = torch.stack([rr * torch.cos(la) * torch.cos(ph),
                                   rr * torch.cos(la) * torch.sin(ph), rr * torch.sin(la)], -1)
        self.weights = None
        self.history = []
        self._build(self._initial_nodes(), init_states=self.obs)
        groups = (self.model.param_groups(cfg["lr"]) if hasattr(self.model, "param_groups")
                  else self.model.parameters())
        self.opt_net = torch.optim.Adam(groups, lr=cfg["lr"])
        self.sched = torch.optim.lr_scheduler.CosineAnnealingLR(self.opt_net, cfg["epochs"],
                                                                eta_min=cfg["lr"] * 0.05)

    # ---------------- node placement ----------------
    def _initial_nodes(self):
        c = self.cfg
        if c["schedule"] == "single":
            return [np.array([0])] * self.P
        if c["schedule"] in ("uniform", "error", "curriculum"):
            return [uniform_nodes(self.N, c["K"])] * self.P
        if c["schedule"] == "kappa":   # first estimate from (noisy) observations
            ws = [phase_space_curvature(self.obs[p, :, :3], self.obs[p, :, 3:], self.dt_obs,
                                        self.gyro_obs) ** c["beta"] for p in range(self.P)]
            self.weights = [w / w.mean() for w in ws]
            return [density_nodes(w, c["K"], c["min_len"]) for w in self.weights]
        raise ValueError(c["schedule"])

    def _build(self, nodes, init_states):
        self.nodes = nodes
        tr, st, ln = [], [], []
        for p, nd in enumerate(nodes):
            s, l = segments_from_nodes(nd, self.N)
            tr += [p] * len(s); st += list(s); ln += list(l)
        self.seg_traj, self.seg_start, self.seg_len = map(np.array, (tr, st, ln))
        self.M, self.Lmax = len(st), int(max(ln))
        z0 = np.stack([init_states[p, s] for p, s in zip(tr, st)])
        self.Z = torch.nn.Parameter(torch.tensor(z0))
        self.opt_z = torch.optim.Adam([self.Z], lr=self.cfg["lr_nodes"])
        # index tensors for targets / masks
        j = np.arange(1, self.Lmax + 1)
        idx = self.seg_start[:, None] + j[None, :]
        self.mask = torch.tensor(j[None, :] <= self.seg_len[:, None], dtype=torch.float64)
        idx = np.minimum(idx, self.N)
        self.target = self.obs_t[self.seg_traj[:, None], idx]             # (M, Lmax, 6)
        self.node_target = self.obs_t[self.seg_traj, self.seg_start]
        nxt = np.arange(self.M) + 1
        self.has_next = torch.tensor(np.append(self.seg_traj[1:] == self.seg_traj[:-1], False))
        self.next_idx = torch.tensor(np.minimum(nxt, self.M - 1))
        self.end_pos = torch.tensor(self.seg_len - 1)

    # ---------------- rollout ----------------
    def rollout(self):
        r, v = self.Z[:, :3], self.Z[:, 3:]
        out = []
        for k in range(1, self.Lmax * self.sub + 1):
            if getattr(self.model, "is_node", False):
                r, v = rk4_step(r, v, DT_MODEL, self.model)
            else:
                r, v = boris_torch(r, v, DT_MODEL, self.model, exact_phase=self.cfg["exact_phase"])
            if k % self.sub == 0:
                out.append(torch.cat([r, v], -1))
        return torch.stack(out, 1)                                         # (M, Lmax, 6)

    def loss(self):
        c = self.cfg
        pred = self.rollout()
        res2 = (((pred - self.target) * self.scale) ** 2).sum(-1)
        L_data = (res2 * self.mask).sum() / self.mask.sum()
        L_node = (((self.Z - self.node_target) * self.scale) ** 2).sum(-1).mean()
        ends = pred[torch.arange(self.M), self.end_pos]
        d = ((ends - self.Z[self.next_idx]) * self.scale) ** 2
        L_cont = (d.sum(-1) * self.has_next).sum() / self.has_next.sum().clamp(min=1)
        reg_fn = getattr(self.model, "reg_residual", self.model.residual)
        L_reg = (reg_fn(self.colloc) ** 2).sum(-1).mean()
        L = L_data + c["lam_node"] * L_node + c["lam_cont"] * L_cont + c["lam_reg"] * L_reg
        harm = getattr(self.model, "harm", None)
        if c["lam_basis2"] > 0 and harm is not None and harm.l_max >= 2:
            L = L + c["lam_basis2"] * (harm.coef[3:8] ** 2).sum()     # shrink only the l = 2 (gradient) terms
        return L, dict(L=L.item(), data=L_data.item(), node=L_node.item(), cont=L_cont.item(),
                       reg=L_reg.item()), pred.detach(), res2.detach()

    # ---------------- adaptive refresh ----------------
    def _predicted_full(self, pred):
        full = np.array(self.obs)
        Z = self.Z.detach().numpy(); P = pred.numpy()
        for m in range(self.M):
            p, s, l = self.seg_traj[m], self.seg_start[m], self.seg_len[m]
            full[p, s] = Z[m]
            full[p, s + 1:s + l + 1] = P[m, :l]   # end of segment overwritten by next node
        for m in range(self.M):
            full[self.seg_traj[m], self.seg_start[m]] = Z[m]
        return full

    def refresh(self, pred, res2):
        c = self.cfg
        full = self._predicted_full(pred)
        new_w = []
        for p in range(self.P):
            if c["schedule"] == "kappa":
                w = phase_space_curvature(full[p, :, :3], full[p, :, 3:], self.dt_obs,
                                          self.gyro_obs) ** c["beta"]
            else:                                              # error equidistribution
                e = np.zeros(self.N + 1)
                for m in np.where(self.seg_traj == p)[0]:
                    s, l = self.seg_start[m], self.seg_len[m]
                    e[s + 1:s + l + 1] = res2[m, :l].numpy()
                e = smooth(e, 25)
                w = np.sqrt(0.5 * (e[1:] + e[:-1]) + 0.1 * e.mean() + 1e-12)
            new_w.append(w / w.mean())
        if self.weights is None:
            self.weights = [np.ones(self.N) for _ in range(self.P)]
        self.weights = [(1 - c["eta"]) * a + c["eta"] * b for a, b in zip(self.weights, new_w)]
        nodes = [density_nodes(w, c["K"], c["min_len"]) for w in self.weights]
        self._build(nodes, init_states=full)

    # ---------------- main loop ----------------
    def merge(self, pred):
        full = self._predicted_full(pred)
        self._build([nd[::2] for nd in self.nodes], init_states=full)

    def fit(self):
        c = self.cfg; t0 = time.time(); last_merge = 0
        for ep in range(c["epochs"]):
            self.opt_net.zero_grad(); self.opt_z.zero_grad()
            L, info, pred, res2 = self.loss()
            L.backward()
            if ep < c["stage1"] and hasattr(self.model, "mlp"):     # staged hybrid: basis first
                for p_ in self.model.mlp.parameters():
                    p_.grad = None
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 10.0)
            self.opt_net.step(); self.opt_z.step(); self.sched.step()
            if c["restart_stage2"] and c["stage1"] > 0 and ep == c["stage1"] - 1:
                # control experiment: stage 2 gets a fresh optimiser and a fresh cosine schedule
                # over (epochs - stage1) epochs, starting from the maximum learning rate
                groups = (self.model.param_groups(c["lr"]) if hasattr(self.model, "param_groups")
                          else self.model.parameters())
                self.opt_net = torch.optim.Adam(groups, lr=c["lr"])
                self.sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                    self.opt_net, c["epochs"] - c["stage1"], eta_min=c["lr"] * 0.05)
            info["epoch"] = ep; info["time"] = time.time() - t0; info["Lmax"] = self.Lmax
            self.history.append(info)
            if (c["schedule"] in ("kappa", "error") and ep >= c["warmup"]
                    and (ep - c["warmup"]) % c["refresh"] == 0 and ep < c["epochs"] - c["refresh"]):
                self.refresh(pred, res2)
            if (c["schedule"] == "curriculum" and info["data"] < c["merge_tol"]
                    and ep - last_merge >= c["merge_gap"] and len(self.nodes[0]) // 2 >= c["K_min"]):
                self.merge(pred); last_merge = ep
                if c["verbose"]:
                    print(f"  merge at ep {ep}: K -> {len(self.nodes[0])}", flush=True)
            info["K_now"] = len(self.nodes[0])
            if c["verbose"] and (ep % 50 == 0 or ep == c["epochs"] - 1):
                print(f"ep {ep:4d} L={info['L']:.4e} data={info['data']:.3e} "
                      f"cont={info['cont']:.3e} reg={info['reg']:.2e} Lmax={self.Lmax} "
                      f"t={info['time']:.0f}s", flush=True)
        return self
