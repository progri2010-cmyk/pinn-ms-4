"""python -m training.run <name> <schedule> <seed> [key=value ...]"""
import sys, json, numpy as np, torch
torch.set_num_threads(1)
from training.mic import Trainer, default_cfg

name, schedule, seed = sys.argv[1], sys.argv[2], int(sys.argv[3])
kw = {}
for a in sys.argv[4:]:
    k, v = a.split("=")
    kw[k] = None if v == "None" else (int(v) if v.isdigit() else (float(v) if v.replace('.', '').replace('e-', '').isdigit() else v))
dpath = kw.pop("data", "data/dataset.npz")
cfg = default_cfg(schedule=schedule, seed=seed, **kw)
cfg["data"] = dpath
data = dict(np.load(dpath))
tr = Trainer(data, cfg).fit()
torch.save({"state": tr.model.state_dict(), "cfg": cfg, "history": tr.history,
            "nodes": [n.tolist() for n in tr.nodes]}, f"outputs/{name}_s{seed}.pt")
print("saved", name, seed)
