"""
data/generate.py -- ground truth with the float64 Boris pusher.

Train: 6 electrons, ~1 bounce each (T=14), observed every 0.02 with noise.
Test : 8 unseen electrons (new L, pitch angle, longitude, gyrophase),
       horizon 140 = 10x the training window, noise-free.
Usage: python -m data.generate [storm_multiplier]
"""
import os, sys
import numpy as np
from functools import partial
from physics.fields import true_field_np, B_S, B_A, TRUTH
from physics.boris import integrate_np

DT_GT, DT_OBS = 0.0005, 0.02
SAVE = int(round(DT_OBS / DT_GT))
T_TRAIN, T_TEST = 14.0, 140.0
SIG_R, SIG_V = 0.002, 0.01


def initial_state(L, alpha_deg, phi, gyrophase):
    r = np.array([L * np.cos(phi), L * np.sin(phi), 0.0])
    B = FIELD(r); b = B / np.linalg.norm(B)
    e1 = np.array([np.cos(phi), np.sin(phi), 0.0]); e1 -= e1.dot(b) * b
    e1 /= np.linalg.norm(e1); e2 = np.cross(b, e1)
    a = np.radians(alpha_deg)
    v = np.cos(a) * b + np.sin(a) * (np.cos(gyrophase) * e1 + np.sin(gyrophase) * e2)
    return r, v


STORM = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0   # multiplier of (B_S, B_A)
NTRAIN = int(sys.argv[2]) if len(sys.argv) > 2 else 6       # 6 (default) or 12
NOISE = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0    # noise multiplier (0 = clean)
FIELD = partial(true_field_np, b_s=STORM * B_S, b_a=STORM * B_A)
OUT = "data/dataset.npz" if STORM == 1.0 else f"data/dataset_storm{STORM:g}.npz"
if NTRAIN != 6:
    OUT = OUT.replace(".npz", f"_n{NTRAIN}.npz")
if TRUTH == "prc":
    OUT = OUT.replace("dataset", "dataset_prc")
if NOISE != 1.0:
    OUT = OUT.replace(".npz", f"_noise{NOISE:g}.npz")


def batch(params, T):
    r0, v0 = zip(*[initial_state(*p) for p in params])
    R, V = integrate_np(np.array(r0), np.array(v0), DT_GT, int(round(T / DT_GT)),
                        FIELD, save_every=SAVE)
    return R, V


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    train = [(3.8, 40, 0.0), (4.2, 50, np.pi / 3), (4.0, 60, 2 * np.pi / 3),
             (3.9, 70, np.pi), (4.1, 80, 4 * np.pi / 3), (4.0, 55, 5 * np.pi / 3)]
    train = [p + (rng.uniform(0, 2 * np.pi),) for p in train]
    test = [(rng.uniform(3.85, 4.15), rng.uniform(45, 75), rng.uniform(0, 2 * np.pi),
             rng.uniform(0, 2 * np.pi)) for _ in range(8)]
    Rtr, Vtr = batch(train, T_TRAIN)
    Rte, Vte = batch(test, T_TEST)
    obs_r = Rtr + NOISE * SIG_R * rng.standard_normal(Rtr.shape)
    obs_v = Vtr + NOISE * SIG_V * rng.standard_normal(Vtr.shape)
    if NTRAIN > 6:     # extra electrons from an independent stream: first 6 and test set unchanged
        rng2 = np.random.default_rng(1)
        extra = [(rng2.uniform(3.8, 4.2), rng2.uniform(40, 80), rng2.uniform(0, 2 * np.pi),
                  rng2.uniform(0, 2 * np.pi)) for _ in range(NTRAIN - 6)]
        Rx, Vx = batch(extra, T_TRAIN)
        Rtr, Vtr = np.concatenate([Rtr, Rx]), np.concatenate([Vtr, Vx])
        obs_r = np.concatenate([obs_r, Rx + SIG_R * rng2.standard_normal(Rx.shape)])
        obs_v = np.concatenate([obs_v, Vx + SIG_V * rng2.standard_normal(Vx.shape)])
        train = train + extra
    rng3 = np.random.default_rng(7)   # validation electrons for model selection (never used in training)
    val = [(rng3.uniform(3.85, 4.15), rng3.uniform(45, 75), rng3.uniform(0, 2 * np.pi),
            rng3.uniform(0, 2 * np.pi)) for _ in range(4)]
    Rva, Vva = batch(val, T_TRAIN)
    val_r = Rva + NOISE * SIG_R * rng3.standard_normal(Rva.shape)
    val_v = Vva + NOISE * SIG_V * rng3.standard_normal(Vva.shape)
    np.savez(OUT, storm=STORM, truth=TRUTH, val_r=val_r, val_v=val_v, val_params=np.array(val), train_r=Rtr, train_v=Vtr, obs_r=obs_r, obs_v=obs_v,
             test_r=Rte, test_v=Vte, train_params=np.array(train),
             test_params=np.array(test), dt_obs=DT_OBS)
    print("train", Rtr.shape, "test", Rte.shape)
