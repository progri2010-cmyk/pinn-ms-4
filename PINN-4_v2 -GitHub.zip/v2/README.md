# PINN-4 v2: Curvature-adaptive multiple shooting for radiation-belt electrons

Kërkon Python ≥ 3.10, numpy, scipy, pandas, matplotlib, torch (mjafton CPU).
Të gjitha komandat ekzekutohen nga dosja rrënjë e projektit.

```
python -m data.generate            # ground truth (Boris float64): data/dataset.npz, ~20 s
python -m training.run NAME SCHEDULE SEED [K=48 epochs=300 beta=0.5 prior=None ...]
python run_grid.py                 # të gjitha eksperimentet e Fazës 4 (2 procese paralele)
python -m evaluation.aggregate     # outputs/results_all.csv, table_main.csv, paired_tests.csv
python -m evaluation.figures       # figures/*.png|pdf
```

SCHEDULE: `single` | `uniform` | `kappa` (me `beta`) | `error`

| Dosja | Përmbajtja |
|---|---|
| physics/fields.py | dipol i normalizuar + stuhi (fusha e vërtetë), ε, b_s, b_a |
| physics/boris.py | Boris numpy (GT) dhe torch (i diferencueshëm) |
| physics/invariants.py | μ, J për kërcim, L e qendrës udhëheqëse, faza e driftit |
| models/field_net.py | B_θ = B_dipol + curl A_θ me Jakobian analitik (div B = 0 ekzakt) |
| training/segments.py | nyjet uniforme / me ekuidistribucion, lakimi në hapësirën fazore |
| training/mic.py | trajnuesi MIC (nyje të trajnueshme, vazhdimësi, rifreskim adaptiv me amortizim) |
| evaluation/ | rollout 10×, metrikat, agregimi, figurat |
| outputs/pilot/ | provat e para (K=24/48/96 uniform), jashtë tabelave |
