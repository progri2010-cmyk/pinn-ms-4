"""Seventh round: staged hybrid (basis-only for 100 epochs, then MLP correction with strong
regularisation lam in {1, 10}), on both truths, exact-phase Boris, 3 seeds."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
cfgs = {}
for lam in ("1.0", "10.0"):
    t = lam.split(".")[0]
    cfgs[f"prc_shyb_l3_lam{t}_K64"] = f"K=64 data=data/dataset_prc.npz model=hybrid l_max=3 lam_reg={lam}"
    cfgs[f"xp_shyb_l2_lam{t}_K48"] = f"K=48 model=hybrid l_max=2 lam_reg={lam}"
jobs = [(n, s, f"{a} epochs=300 exact_phase=True stage1=100") for s in range(3) for n, a in cfgs.items()]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    env = dict(os.environ, RB_TRUTH="prc" if name.startswith("prc") else "storm")
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=env)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID7 DONE")
