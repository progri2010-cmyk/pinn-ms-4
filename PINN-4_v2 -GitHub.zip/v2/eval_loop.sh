#!/bin/bash
# re-evaluate (cached) until the final queue is done, then one last pass
PRC="prc_mlp_K64 prc_harm_l1_K64 prc_harm_l2_K64 prc_harm_l3_K64 prc_hyb_l2_K64 prc_hyb_l3_K64 prc_shyb_l2_lam001_K64 prc_shyb_l2_lam01_K64 prc_shyb_l3_lam001_K64 prc_shyb_l3_lam01_K64 prc_shyb_l3_lam1_K64 prc_shyb_l3_lam10_K64 prc_shyb_l1_K64 prc_shyb_l2b01_K64 prc_shyb_l2b1_K64 prc_shyb_l2_st25_K64 prc_shyb_l2_st50_K64 prc_shyb_l2_lamreg0001_K64 prc_shyb_l2_st25r_K64 prc_shyb_l2_st50r_K64 prc_shyb_l2_st100r_K64 prc_mlp_ep200_K64 prc_node_K64 prc_mlp_K24 prc_mlp_K32 prc_mlp_K48"
STORM="xp_mlp_K48 harm_l1_K48 xp_harm_l2_K48 xp_harm_l3_K48 xp_hyb_l2_K48 xp_shyb_l2_lam001_K48 xp_shyb_l2_lam01_K48 xp_shyb_l2_lam1_K48 xp_shyb_l2_lam10_K48 xp_shyb_l1_K48 xp_shyb_l2b01_K48 xp_shyb_l2b1_K48 xp_shyb_l2_st25_K48 xp_shyb_l2_st50_K48 xp_shyb_l2_lamreg0001_K48 xp_node_K48"
while true; do
  done_flag=$(grep -c "FINAL DONE" outputs/logs/final.log)
  RB_TRUTH=prc python3 -m evaluation.eval_truth data/dataset_prc.npz $PRC > outputs/logs/evalloop_prc.log 2>&1
  RB_TRUTH=storm python3 -m evaluation.eval_truth data/dataset.npz $STORM > outputs/logs/evalloop_storm.log 2>&1
  if [ "$done_flag" -ge 1 ]; then echo EVAL LOOP DONE > outputs/logs/evalloop.flag; break; fi
  sleep 60
done
