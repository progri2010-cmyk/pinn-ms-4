"""Fifth round: exact-phase Boris inside training (MLP and harmonic residuals), K=48, 3 seeds."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
cfgs = {"xp_mlp_K48": "", "xp_harm_l2_K48": "model=harmonic l_max=2 lr=0.01 lam_reg=0.0",
        "xp_harm_l3_K48": "model=harmonic l_max=3 lr=0.01 lam_reg=0.0"}
jobs = [(n, s, f"K=48 epochs=300 exact_phase=True {x}") for s in range(3) for n, x in cfgs.items()]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f, stderr=subprocess.STDOUT)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID5 DONE")
