"""Eleventh round: hybrids with less imposed gradient structure, both truths, 3 seeds.
(a) staged hybrid with l = 1 basis (uniform field) + MLP
(b) staged hybrid with l <= 2 basis, penalty lam_b * |c_{l=2}|^2 on the gradient terms, lam_b in {0.1, 1}"""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
S = "K=48 epochs=300 exact_phase=True stage1=100 model=hybrid lam_reg=0.1"
P = "K=64 epochs=300 exact_phase=True stage1=100 model=hybrid lam_reg=0.1 data=data/dataset_prc.npz"
cfgs = {"xp_shyb_l1_K48": f"{S} l_max=1", "prc_shyb_l1_K64": f"{P} l_max=1",
        "xp_shyb_l2b01_K48": f"{S} l_max=2 lam_basis2=0.1", "prc_shyb_l2b01_K64": f"{P} l_max=2 lam_basis2=0.1",
        "xp_shyb_l2b1_K48": f"{S} l_max=2 lam_basis2=1.0", "prc_shyb_l2b1_K64": f"{P} l_max=2 lam_basis2=1.0"}
jobs = [(n, s, a) for s in range(3) for n, a in cfgs.items()]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    env = dict(os.environ, RB_TRUTH="prc" if name.startswith("prc") else "storm")
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=env)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID11 DONE")
