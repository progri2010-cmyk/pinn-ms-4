"""Second analysis round: curriculum, threshold seeds, data scaling."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
E = "epochs=300"
jobs = []
for s in range(5):
    jobs.append((f"curriculum_K96to24_s{s}", "curriculum", s, f"K=96 K_min=24 {E}"))
    jobs.append((f"uniform_K96_s{s}", "uniform", s, f"K=96 {E}"))
for s in range(3):
    jobs.append((f"data12_uniform_K48_s{s}", "uniform", s, f"K=48 {E} data=data/dataset_n12.npz"))
thr = {0.5: {12: (1, 2), 16: (1, 2), 14: (0, 1, 2), 20: (0, 1, 2)},
       1.0: {16: (1, 2), 64: (1, 2), 40: (0, 1, 2)},
       2.0: {64: (1, 2), 96: (1, 2), 48: (1, 2), 80: (0, 1, 2)}}
for storm, d in thr.items():
    path = "data/dataset.npz" if storm == 1.0 else f"data/dataset_storm{storm:g}.npz"
    for K, seeds in d.items():
        for s in seeds:
            jobs.append((f"threshold/thr_storm{storm:g}_K{K}_s{s}", "uniform", s, f"K={K} {E} data={path}"))

def run(j):
    full, sch, s, args = j
    name = full.rsplit("_s", 1)[0]
    if os.path.exists(f"outputs/{full}.pt"): return
    with open(f"outputs/logs/{os.path.basename(full)}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} {sch} {s} {args}".split(), stdout=f, stderr=subprocess.STDOUT)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID2 DONE")
