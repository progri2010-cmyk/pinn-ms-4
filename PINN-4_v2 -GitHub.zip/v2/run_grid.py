"""Phase 4 grid: python run_grid.py  (2 parallel workers, skips finished runs)"""
import subprocess, os, itertools
from concurrent.futures import ThreadPoolExecutor

E = "epochs=300"
jobs = []
SCHED = {"uniform": ("uniform", ""), "kappa05": ("kappa", "beta=0.5"),
         "kappa1": ("kappa", "beta=1.0"), "error": ("error", "")}
for K in (24, 32, 48):
    seeds = range(5) if K == 48 else range(3)
    for s, (name, (sch, extra)) in itertools.product(seeds, SCHED.items()):
        jobs.append((f"{name}_K{K}", sch, s, f"K={K} {E} {extra}"))
for s in range(3):
    jobs.append(("blackbox_K48", "uniform", s, f"K=48 {E} prior=None"))
for s in range(2):
    jobs.append(("single", "single", s, f"{E}"))


def run(j):
    name, sch, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"):
        return
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} {sch} {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT)

jobs.sort(key=lambda j: j[0] == "single")   # long single-shooting runs last
with ThreadPoolExecutor(2) as ex:
    list(ex.map(run, jobs))
print("GRID DONE")
