"""Sixth round: out-of-basis truth (RB_TRUTH=prc), exact-phase Boris, 3 seeds.
Also: hybrid on the in-basis storm field (sanity: hybrid must not lose the basis advantage)."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
P = "K=64 epochs=300 exact_phase=True data=data/dataset_prc.npz"
cfgs = {"prc_mlp_K64": f"{P}",
        "prc_harm_l1_K64": f"{P} model=harmonic l_max=1 lr=0.01 lam_reg=0.0",
        "prc_harm_l2_K64": f"{P} model=harmonic l_max=2 lr=0.01 lam_reg=0.0",
        "prc_harm_l3_K64": f"{P} model=harmonic l_max=3 lr=0.01 lam_reg=0.0",
        "prc_hyb_l2_K64": f"{P} model=hybrid l_max=2 lam_reg=0.1",
        "prc_hyb_l3_K64": f"{P} model=hybrid l_max=3 lam_reg=0.1",
        "xp_hyb_l2_K48": "K=48 epochs=300 exact_phase=True model=hybrid l_max=2 lam_reg=0.1"}
jobs = [(n, s, a) for s in range(3) for n, a in cfgs.items()]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    env = dict(os.environ, RB_TRUTH="prc" if name.startswith("prc") else "storm")
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=env)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID6 DONE")
