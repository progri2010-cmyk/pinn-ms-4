"""Thirteenth round: 10 seeds for the validation-selected out-of-basis configuration (staged hybrid l<=2, stage1=50)."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
A = "K=64 epochs=300 exact_phase=True model=hybrid l_max=2 data=data/dataset_prc.npz stage1=50 lam_reg=0.1"
jobs = [("prc_shyb_l2_st50_K64", s, A) for s in range(3, 10)]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=dict(os.environ, RB_TRUTH="prc"))
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID13 DONE")
