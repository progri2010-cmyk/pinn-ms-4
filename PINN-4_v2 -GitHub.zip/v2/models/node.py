"""
models/node.py -- unstructured baseline: second-order Neural ODE
    dr/dt = v,   dv/dt = f_theta(r, v)      (tanh MLP, 6 -> h -> h -> h -> 3)
integrated with classical RK4. No Lorentz form, no magnetic field, no energy
or volume conservation: the network must learn the gyration itself.
Inputs are scaled as (r / 4, v); outputs by 1/eps (the size of v x B / eps).
The output layer starts at zero (straight-line motion), as the hybrid models do.
"""
import torch
import torch.nn as nn
from physics.fields import EPS


class SecondOrderNODE(nn.Module):
    is_node = True

    def __init__(self, hidden=64, depth=3):
        super().__init__()
        dims = [6] + [hidden] * depth
        layers = []
        for a, b in zip(dims[:-1], dims[1:]):
            l = nn.Linear(a, b); nn.init.xavier_normal_(l.weight); nn.init.zeros_(l.bias)
            layers += [l, nn.Tanh()]
        out = nn.Linear(hidden, 3); nn.init.zeros_(out.weight); nn.init.zeros_(out.bias)
        self.net = nn.Sequential(*layers, out)
        self.double()

    def accel(self, r, v):
        return self.net(torch.cat([r / 4.0, v], -1)) / EPS

    def residual(self, r):                       # no field: nothing to regularise
        return torch.zeros_like(r)


def rk4_step(r, v, dt, model):
    a1 = model.accel(r, v)
    r2, v2 = r + 0.5 * dt * v, v + 0.5 * dt * a1; a2 = model.accel(r2, v2)
    r3, v3 = r + 0.5 * dt * v2, v + 0.5 * dt * a2; a3 = model.accel(r3, v3)
    r4, v4 = r + dt * v3, v + dt * a3; a4 = model.accel(r4, v4)
    r_new = r + dt / 6 * (v + 2 * v2 + 2 * v3 + v4)
    v_new = v + dt / 6 * (a1 + 2 * a2 + 2 * a3 + a4)
    return r_new, v_new
