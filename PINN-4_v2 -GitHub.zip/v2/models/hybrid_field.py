"""
models/hybrid_field.py -- physics basis + small learned correction:
    B_theta = B_dipole + grad Phi_c (harmonic, l <= l_max) + curl A_theta (MLP)
Both parts are divergence-free by construction. The MLP output layer starts at
zero, and only the MLP part is regularised (reg_residual), so the network fills
in only what the harmonic basis cannot represent (e.g. in-situ currents).
"""
import torch.nn as nn
from physics.fields import dipole_torch
from models.field_net import CurlField
from models.harmonic_field import HarmonicField


class HybridField(nn.Module):
    def __init__(self, l_max=2, hidden=64, depth=3, out_scale=0.1):
        super().__init__()
        self.harm = HarmonicField(l_max)
        self.mlp = CurlField(hidden, depth, prior="dipole", out_scale=out_scale)   # zero-init output
        self.double()

    def residual(self, r):
        return self.harm.residual(r) + self.mlp.residual(r)

    def reg_residual(self, r):
        return self.mlp.residual(r)

    def forward(self, r):
        return self.residual(r) + dipole_torch(r)

    def param_groups(self, lr, lr_basis=1e-2):
        return [{"params": self.harm.parameters(), "lr": lr_basis},
                {"params": self.mlp.parameters(), "lr": lr}]
