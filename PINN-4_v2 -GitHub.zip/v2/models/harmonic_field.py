"""
models/harmonic_field.py -- physics-structured residual: external vacuum field
    B_theta = B_dipole + grad Phi,   Phi = sum_k c_k P_k(r / s),
P_k = real harmonic polynomials (solid harmonics r^l Y_lm) of degree 1..l_max:
3 + 5 + 7 = 15 coefficients for l_max = 3. div B = curl B = 0 by construction.
This is the standard form of external-field expansions in geomagnetism.
Gradients are hand-coded so the model also runs under torch.no_grad().
"""
import torch
import torch.nn as nn
from physics.fields import dipole_torch


def _basis_grad(r):
    x, y, z = r[..., 0], r[..., 1], r[..., 2]
    o, n = torch.ones_like(x), torch.zeros_like(x)
    G = {1: [(o, n, n), (n, o, n), (n, n, o)],
         2: [(y, x, n), (n, z, y), (z, n, x), (2 * x, -2 * y, n), (-2 * x, -2 * y, 4 * z)],
         3: [(3 * x * x - 3 * y * y, -6 * x * y, n),
             (6 * x * y, 3 * x * x - 3 * y * y, n),
             (2 * x * z, -2 * y * z, x * x - y * y),
             (y * z, x * z, x * y),
             (4 * z * z - 3 * x * x - y * y, -2 * x * y, 8 * x * z),
             (-2 * x * y, 4 * z * z - x * x - 3 * y * y, 8 * y * z),
             (-6 * x * z, -6 * y * z, 6 * z * z - 3 * x * x - 3 * y * y)]}
    return G


class HarmonicField(nn.Module):
    def __init__(self, l_max=3, length=4.0, prior="dipole"):
        super().__init__()
        self.l_max, self.length, self.prior = l_max, length, prior
        n = {1: 3, 2: 8, 3: 15}[l_max]
        self.coef = nn.Parameter(torch.zeros(n, dtype=torch.float64))
        self.double()

    def residual(self, r):
        G = _basis_grad(r / self.length)
        cols = [torch.stack(g, -1) for l in range(1, self.l_max + 1) for g in G[l]]
        return torch.einsum("k,...kj->...j", self.coef, torch.stack(cols, -2)) / self.length

    def forward(self, r):
        return self.residual(r) + dipole_torch(r)
