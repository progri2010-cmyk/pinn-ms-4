"""
models/field_net.py -- learned magnetic field  B_theta(r) = B_known(r) + curl A_theta(r).

A_theta is a tanh MLP whose input Jacobian dA/dr is propagated alongside the
activations (forward-mode, closed form), so curl A costs ~3 extra matmuls
instead of three double-backward autograd passes. div(curl A) = 0 holds
identically: the learned field is always a valid magnetic field.

prior="dipole": hybrid model (Model A) -- network learns only the residual,
                last layer zero-initialised so training starts at known physics.
prior=None    : black-box field (Model B ablation).
"""
import torch
import torch.nn as nn
from physics.fields import dipole_torch


class CurlField(nn.Module):
    def __init__(self, hidden=64, depth=3, prior="dipole", out_scale=0.1,
                 center=(0.0, 0.0, 0.0), length=4.0):
        super().__init__()
        dims = [3] + [hidden] * depth
        self.layers = nn.ModuleList(nn.Linear(a, b) for a, b in zip(dims[:-1], dims[1:]))
        self.out = nn.Linear(hidden, 3)
        for l in self.layers:
            nn.init.xavier_normal_(l.weight); nn.init.zeros_(l.bias)
        if prior == "dipole":
            nn.init.zeros_(self.out.weight)
        else:
            nn.init.xavier_normal_(self.out.weight)
        nn.init.zeros_(self.out.bias)
        self.prior, self.out_scale, self.length = prior, out_scale, length
        self.register_buffer("center", torch.tensor(center, dtype=torch.float64))
        self.double()

    def potential_and_jac(self, r):
        h = (r - self.center) / self.length
        J = torch.eye(3, dtype=r.dtype, device=r.device).expand(*r.shape[:-1], 3, 3) / self.length
        for l in self.layers:
            h = torch.tanh(l(h))
            J = (1 - h * h).unsqueeze(-1) * torch.matmul(l.weight, J)
        A = self.out_scale * self.out(h)
        G = self.out_scale * torch.matmul(self.out.weight, J)    # G[i,j] = dA_i/dr_j
        return A, G

    def residual(self, r):
        _, G = self.potential_and_jac(r)
        return torch.stack([G[..., 2, 1] - G[..., 1, 2],
                            G[..., 0, 2] - G[..., 2, 0],
                            G[..., 1, 0] - G[..., 0, 1]], -1)

    def forward(self, r):
        dB = self.residual(r)
        return dB + dipole_torch(r) if self.prior == "dipole" else dB
