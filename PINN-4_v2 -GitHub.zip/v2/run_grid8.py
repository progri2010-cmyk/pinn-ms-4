"""Eighth round: staged hybrid with weak MLP regularisation lam in {0.01, 0.1} on both truths
(completes the lam grid {0.01, 0.1, 1, 10} for validation-based selection), 3 seeds."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
cfgs = {}
for lam, t in (("0.01", "001"), ("0.1", "01")):
    cfgs[f"xp_shyb_l2_lam{t}_K48"] = f"K=48 model=hybrid l_max=2 lam_reg={lam}"
    cfgs[f"prc_shyb_l3_lam{t}_K64"] = f"K=64 data=data/dataset_prc.npz model=hybrid l_max=3 lam_reg={lam}"
    cfgs[f"prc_shyb_l2_lam{t}_K64"] = f"K=64 data=data/dataset_prc.npz model=hybrid l_max=2 lam_reg={lam}"
jobs = [(n, s, f"{a} epochs=300 exact_phase=True stage1=100") for s in range(3) for n, a in cfgs.items()]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    env = dict(os.environ, RB_TRUTH="prc" if name.startswith("prc") else "storm")
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=env)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID8 DONE")
