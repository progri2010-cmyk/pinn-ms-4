"""Twelfth round: is the stage-1 lock-in the cause of the drift penalty?
staged hybrid l<=2: stage1 in {25, 50} (lam_reg 0.1), and stage1=100 with lam_reg=0.001 (same as MLP). Both truths, 3 seeds."""
import subprocess, os
from concurrent.futures import ThreadPoolExecutor
S = "K=48 epochs=300 exact_phase=True model=hybrid l_max=2"
P = "K=64 epochs=300 exact_phase=True model=hybrid l_max=2 data=data/dataset_prc.npz"
cfgs = {}
for st in (25, 50):
    cfgs[f"xp_shyb_l2_st{st}_K48"] = f"{S} stage1={st} lam_reg=0.1"
    cfgs[f"prc_shyb_l2_st{st}_K64"] = f"{P} stage1={st} lam_reg=0.1"
cfgs["xp_shyb_l2_lamreg0001_K48"] = f"{S} stage1=100 lam_reg=0.001"
cfgs["prc_shyb_l2_lamreg0001_K64"] = f"{P} stage1=100 lam_reg=0.001"
jobs = [(n, s, a) for s in range(3) for n, a in cfgs.items()]
def run(j):
    name, s, args = j
    if os.path.exists(f"outputs/{name}_s{s}.pt"): return
    env = dict(os.environ, RB_TRUTH="prc" if name.startswith("prc") else "storm")
    with open(f"outputs/logs/{name}_s{s}.log", "w") as f:
        subprocess.run(f"python3 -m training.run {name} uniform {s} {args}".split(), stdout=f,
                       stderr=subprocess.STDOUT, env=env)
with ThreadPoolExecutor(2) as ex: list(ex.map(run, jobs))
print("GRID12 DONE")
